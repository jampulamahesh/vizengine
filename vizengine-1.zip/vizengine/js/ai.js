// AI integration layer. VIZENGINE never fakes AI answers: without a configured
// endpoint every AI feature says so. Works with any OpenAI-compatible
// /chat/completions endpoint (OpenAI, OpenRouter, Groq, Together, Ollama, LM Studio, a self-hosted proxy…).
import { esc, store, save } from './util.js';

export const DEFAULT_CFG = { endpoint: 'https://api.openai.com/v1/chat/completions', model: 'gpt-4o-mini', key: '' };
export const aiConfig = () => ({ ...DEFAULT_CFG, ...store('ai', {}) });
export const aiReady = () => !!aiConfig().key || /localhost|127\.0\.0\.1/.test(aiConfig().endpoint);

export async function askAI(messages, { signal } = {}) {
  const c = aiConfig();
  if (!aiReady()) throw new Error('NOT_CONFIGURED');
  const headers = { 'Content-Type': 'application/json' };
  if (c.key) headers.Authorization = 'Bearer ' + c.key;
  const r = await fetch(c.endpoint, { method: 'POST', headers, body: JSON.stringify({ model: c.model, messages }), signal });
  if (!r.ok) throw new Error(`AI request failed (${r.status}): ${(await r.text()).slice(0, 300)}`);
  const j = await r.json();
  return j.choices?.[0]?.message?.content ?? JSON.stringify(j);
}

const BASE = 'You are VIZ AI inside VIZENGINE, an engineering education platform. Be accurate; show formulas and units; say when you are unsure. Keep answers structured and concise. Use Markdown. ';
export const AGENTS = {
  tutor: { name: 'Tutor', system: BASE + 'Act as an engineering tutor: build intuition first, then formulas, then a worked example. Suggest a visualisation (e.g. a lab in VIZENGINE) when useful.' },
  project: { name: 'Project mentor', system: BASE + 'Act as a project mentor: clarify the objective, propose architecture, components with ratings, step-by-step build plan, test plan and risks.' },
  exam: { name: 'Exam coach', system: BASE + 'Act as an exam coach. For numericals use: Given → Formula → Substitution → Calculation → Final answer (with units). For theory use: Concept → Explanation → Example → Exam-ready answer.' },
  viz: { name: 'Visualisation', system: BASE + 'Convert the concept into a visualisation specification: entities, parameters (with ranges), equations, and what should animate. Output JSON followed by a short explanation.' },
  design: { name: 'Design', system: BASE + 'Act as a technical-diagram assistant: describe block diagrams, flowcharts or circuit layouts step by step so they can be drawn in a canvas editor.' },
  model3d: { name: '3D model spec', system: BASE + 'Prepare 3D model specifications: parts, dimensions in mm, materials, tolerances and printing considerations. Output a JSON parts list followed by notes.' },
  docs: { name: 'Documentation', system: BASE + 'Write engineering project documentation: abstract, introduction, methodology, results, conclusion, in clear academic English.' },
};

// small, safe Markdown renderer (escapes HTML first)
export function md(src) {
  const blocks = [];
  let s = esc(src).replace(/```[\w-]*\n?([\s\S]*?)```/g, (m, c) => { blocks.push(`<pre><code>${c.replace(/\n$/, '')}</code></pre>`); return `\u0000${blocks.length - 1}\u0000`; });
  s = s.replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
  const out = []; let list = null;
  const close = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const line of s.split('\n')) {
    let m;
    if ((m = line.match(/^(#{1,4})\s+(.*)/))) { close(); out.push(`<h4>${m[2]}</h4>`); }
    else if ((m = line.match(/^\s*[-*]\s+(.*)/))) { if (list !== 'ul') { close(); out.push('<ul>'); list = 'ul'; } out.push(`<li>${m[1]}</li>`); }
    else if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { if (list !== 'ol') { close(); out.push('<ol>'); list = 'ol'; } out.push(`<li>${m[1]}</li>`); }
    else if (!line.trim()) close();
    else { close(); out.push(`<p>${line}</p>`); }
  }
  close();
  return out.join('').replace(/\u0000(\d+)\u0000/g, (m, i) => blocks[+i]);
}

export function openAISettings(onSave) {
  const c = aiConfig();
  const d = document.createElement('dialog');
  d.innerHTML = `<form method="dialog"><h3>Connect an AI model</h3>
    <p class="muted" style="font-size:.88rem">Any OpenAI-compatible chat-completions endpoint. Settings are stored only in this browser (localStorage).</p>
    <label class="f">Endpoint URL</label><input type="url" id="ai-ep" value="${esc(c.endpoint)}">
    <label class="f">Model</label><input type="text" id="ai-model" value="${esc(c.model)}">
    <label class="f">API key</label><input type="password" id="ai-key" value="${esc(c.key)}" placeholder="sk-…" autocomplete="off">
    <div class="notice warn"><b>Security:</b> a key typed here is visible to anyone using this browser profile and is sent directly from the browser. For a public deployment, put the key behind your own server or proxy and enter that proxy URL instead. Browser calls also need the provider to allow CORS.</div>
    <div class="toolbar" style="justify-content:flex-end;margin-top:10px"><button class="btn" value="cancel">Cancel</button><button class="btn danger" id="ai-clear" value="clear">Remove key</button><button class="btn primary" id="ai-save" value="save">Save</button></div></form>`;
  document.body.appendChild(d);
  d.addEventListener('close', () => {
    if (d.returnValue === 'save') { save('ai', { endpoint: d.querySelector('#ai-ep').value.trim(), model: d.querySelector('#ai-model').value.trim(), key: d.querySelector('#ai-key').value.trim() }); onSave && onSave(); }
    if (d.returnValue === 'clear') { save('ai', { ...aiConfig(), key: '' }); onSave && onSave(); }
    d.remove();
  });
  d.showModal();
}
