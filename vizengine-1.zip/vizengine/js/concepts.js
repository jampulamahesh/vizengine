// 2D animated engineering concepts for the Visual Learning Lab.
// Every number shown is computed from the parameters (no canned results).
import { drawGear, colors, graph, rng, fmt } from './util.js';

const TAU = Math.PI * 2;
export const STROKES = [
  ['Intake', 0, 180, '#4aa3ff', 'Intake valve open. The piston moves down and draws in the air–fuel mixture.'],
  ['Compression', 180, 360, '#ffb547', 'Both valves closed. The piston moves up and compresses the mixture.'],
  ['Power', 360, 540, '#ff6b4a', 'Spark ignites the mixture. Expanding gas pushes the piston down and does work.'],
  ['Exhaust', 540, 720, '#9aa7b8', 'Exhaust valve open. The piston moves up and pushes burnt gas out.'],
];
export const strokeAt = a => STROKES.find(s => a >= s[1] && a < s[2]) || STROKES[3];

function engine2D(ctx, w, h, s) {
  const a = s.angle, th = a * Math.PI / 180, r = 34, l = 108;
  const yp = r * Math.cos(th) + Math.sqrt(l * l - r * r * Math.sin(th) ** 2);
  const st = strokeAt(a);
  const k = Math.min(w / 250, h / 360);
  ctx.save(); ctx.translate(w / 2, h * 0.78); ctx.scale(k, k);
  const headY = -(r + l + 30);
  // gas
  ctx.fillStyle = st[3]; ctx.globalAlpha = .28;
  ctx.fillRect(-26, headY, 52, -(yp + 20) - headY);
  ctx.globalAlpha = 1;
  if (a >= 360 && a < 430) {
    const f = 1 - (a - 360) / 70;
    const g = ctx.createRadialGradient(0, headY + 14, 2, 0, headY + 14, 30);
    g.addColorStop(0, `rgba(255,220,120,${f})`); g.addColorStop(1, 'rgba(255,90,40,0)');
    ctx.fillStyle = g; ctx.fillRect(-26, headY, 52, 40);
  }
  // cylinder walls and head
  ctx.strokeStyle = colors.text; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(-26, headY); ctx.lineTo(-26, 50); ctx.moveTo(26, headY); ctx.lineTo(26, 50); ctx.stroke();
  ctx.fillStyle = colors.panel2; ctx.fillRect(-34, headY - 16, 68, 16); ctx.strokeRect(-34, headY - 16, 68, 16);
  // valves
  const lift = (open, start) => open ? 7 * Math.sin(Math.PI * (a - start) / 180) : 0;
  const li = lift(a < 180, 0), le = lift(a >= 540, 540);
  ctx.strokeStyle = colors.accent; ctx.lineWidth = 3;
  [[-14, li], [14, le]].forEach(([x, d]) => {
    ctx.beginPath(); ctx.moveTo(x, headY - 26); ctx.lineTo(x, headY + d); ctx.stroke();
    ctx.fillStyle = colors.accent; ctx.fillRect(x - 8, headY + d, 16, 3);
  });
  ctx.fillStyle = colors.mute; ctx.fillRect(-3, headY - 28, 6, 12);
  // piston
  ctx.fillStyle = colors.panel2; ctx.strokeStyle = colors.text; ctx.lineWidth = 2;
  ctx.fillRect(-25, -(yp + 20), 50, 40); ctx.strokeRect(-25, -(yp + 20), 50, 40);
  ctx.beginPath(); ctx.moveTo(-25, -(yp + 12)); ctx.lineTo(25, -(yp + 12)); ctx.moveTo(-25, -(yp + 7)); ctx.lineTo(25, -(yp + 7)); ctx.stroke();
  // rod + crank
  const px = r * Math.sin(th), py = -r * Math.cos(th);
  ctx.strokeStyle = colors.mute; ctx.lineWidth = 8; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(0, -yp); ctx.stroke();
  ctx.lineWidth = 2; ctx.strokeStyle = colors.line; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.stroke();
  ctx.fillStyle = colors.accent2; ctx.beginPath(); ctx.arc(px, py, 7, 0, TAU); ctx.fill();
  ctx.fillStyle = colors.text; ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
  ctx.fillStyle = colors.accent2; ctx.beginPath(); ctx.arc(-px * 1.2, -py * 1.2, 10, 0, TAU); ctx.globalAlpha = .6; ctx.fill(); ctx.globalAlpha = 1;
  ctx.restore();
  ctx.fillStyle = st[3]; ctx.font = '700 22px Space Grotesk, sans-serif'; ctx.fillText(st[0] + ' stroke', 16, 32);
  ctx.fillStyle = colors.mute; ctx.font = '13px JetBrains Mono, monospace'; ctx.fillText('crank angle ' + String(Math.round(a)).padStart(3, '0') + '° / 720°', 16, 52);
}

function gearsDraw(ctx, w, h, s, t, dt) {
  s.phi = (s.phi || 0) + dt * s.rpm * TAU / 60;
  const n1 = Math.round(s.n1), n2 = Math.round(s.n2);
  let m = w * 0.42 / (n1 + n2); m = Math.min(m, h * 0.36 / Math.max(n1, n2));
  const r1 = n1 * m, r2 = n2 * m, cx1 = (w - 2 * (r1 + r2)) / 2 + r1, cx2 = cx1 + r1 + r2, cy = h / 2;
  const p2 = TAU / n2;
  const rot1 = s.phi, rot2 = Math.PI - 1.1 * p2 - s.phi * n1 / n2;
  drawGear(ctx, cx1, cy, r1 + m, n1, rot1, colors.accent, colors.text, 2.2 * m);
  drawGear(ctx, cx2, cy, r2 + m, n2, rot2, colors.accent2, colors.text, 2.2 * m);
  ctx.setLineDash([5, 5]); ctx.strokeStyle = colors.mute; ctx.lineWidth = 1;
  [[cx1, r1], [cx2, r2]].forEach(([x, r]) => { ctx.beginPath(); ctx.arc(x, cy, r, 0, TAU); ctx.stroke(); });
  ctx.setLineDash([]);
  ctx.fillStyle = colors.text; ctx.font = '600 13px Space Grotesk, sans-serif';
  ctx.fillText(`Driver  N=${n1}`, cx1 - 30, cy + r1 + m + 22); ctx.fillText(`Driven  N=${n2}`, cx2 - 30, cy + r2 + m + 22);
}

const NN_LAYERS = [3, 5, 4, 2];
function nnForward(x) {
  const R = rng(11); let a = x.slice(); const acts = [a], W = [];
  for (let l = 1; l < NN_LAYERS.length; l++) {
    const w = Array.from({ length: NN_LAYERS[l] }, () => Array.from({ length: NN_LAYERS[l - 1] }, () => R() * 2 - 1));
    W.push(w);
    a = w.map(row => Math.tanh(row.reduce((s, v, i) => s + v * acts[l - 1][i], 0)));
    acts.push(a);
  }
  return { acts, W };
}
function nnDraw(ctx, w, h, s, t) {
  const { acts, W } = nnForward([s.x1, s.x2, s.x3]);
  const pos = NN_LAYERS.map((n, l) => Array.from({ length: n }, (_, i) => [w * (0.12 + 0.76 * l / (NN_LAYERS.length - 1)), h * (0.5 + (i - (n - 1) / 2) * 0.16)]));
  for (let l = 1; l < NN_LAYERS.length; l++) for (let j = 0; j < NN_LAYERS[l]; j++) for (let i = 0; i < NN_LAYERS[l - 1]; i++) {
    const wt = W[l - 1][j][i], [x1, y1] = pos[l - 1][i], [x2, y2] = pos[l][j];
    ctx.strokeStyle = wt > 0 ? colors.accent2 : '#4aa3ff'; ctx.globalAlpha = .12 + .5 * Math.abs(wt); ctx.lineWidth = 1 + 1.5 * Math.abs(wt);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.globalAlpha = 1;
    const f = ((t * 0.6 + l * .3 + i * .07) % 1);
    ctx.fillStyle = colors.text; ctx.globalAlpha = .6 * Math.abs(acts[l - 1][i]);
    ctx.beginPath(); ctx.arc(x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, 2.5, 0, TAU); ctx.fill(); ctx.globalAlpha = 1;
  }
  acts.forEach((layer, l) => layer.forEach((v, i) => {
    const [x, y] = pos[l][i];
    ctx.beginPath(); ctx.arc(x, y, 15, 0, TAU);
    ctx.fillStyle = v >= 0 ? `rgba(255,181,71,${.15 + .85 * Math.abs(v)})` : `rgba(74,163,255,${.15 + .85 * Math.abs(v)})`; ctx.fill();
    ctx.strokeStyle = colors.text; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = colors.text; ctx.font = '10px JetBrains Mono, monospace'; ctx.textAlign = 'center'; ctx.fillText(fmt(v, 2), x, y + 3.5); ctx.textAlign = 'left';
  }));
  ctx.fillStyle = colors.mute; ctx.font = '12px Space Grotesk, sans-serif';
  ['Input', 'Hidden 1', 'Hidden 2', 'Output'].forEach((n, l) => ctx.fillText(n, pos[l][0][0] - 22, 22));
}

function beamCalc(s) {
  const P = s.P * 1e3, L = s.L, E = s.E * 1e9, I = s.I * 1e-8;
  return { d: P * L ** 3 / (48 * E * I) * 1000, R: s.P / 2, M: s.P * s.L / 4 };
}
function beamDraw(ctx, w, h, s) {
  const { d } = beamCalc(s);
  const x0 = w * 0.1, x1 = w * 0.9, y0 = h * 0.4, L = x1 - x0;
  const maxPx = Math.min(80, h * 0.25);
  ctx.strokeStyle = colors.accent; ctx.lineWidth = 8; ctx.lineCap = 'round'; ctx.beginPath();
  for (let i = 0; i <= 60; i++) {
    const u = i / 60, v = u <= .5 ? u : 1 - u;
    const norm = v * (3 - 4 * v * v); // = 1 at midspan (x = L/2)
    const y = y0 + norm * maxPx;
    i ? ctx.lineTo(x0 + u * L, y) : ctx.moveTo(x0 + u * L, y);
  }
  ctx.stroke();
  ctx.strokeStyle = colors.line; ctx.lineWidth = 1; ctx.setLineDash([5, 5]); ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y0); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = colors.mute; [x0, x1].forEach((x, i) => { ctx.beginPath(); ctx.moveTo(x, y0 + 6); ctx.lineTo(x - 14, y0 + 34); ctx.lineTo(x + 14, y0 + 34); ctx.closePath(); ctx.fill(); });
  const mx = (x0 + x1) / 2, my = y0 + maxPx;
  ctx.strokeStyle = colors.danger; ctx.fillStyle = colors.danger; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(mx, my - 90); ctx.lineTo(mx, my - 16); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(mx - 8, my - 24); ctx.lineTo(mx + 8, my - 24); ctx.lineTo(mx, my - 8); ctx.fill();
  ctx.font = '600 13px Space Grotesk, sans-serif'; ctx.fillText(`P = ${fmt(s.P)} kN`, mx + 12, my - 60);
  ctx.fillStyle = colors.mute; ctx.font = '12px JetBrains Mono, monospace';
  ctx.fillText(`L = ${fmt(s.L)} m`, (x0 + x1) / 2 - 24, y0 + 56);
  ctx.fillText('Deflected shape drawn at a fixed visual scale (true δmax is in the panel).', x0, h - 16);
}

function rcDraw(ctx, w, h, s, t, dt) {
  const tau = s.R * s.C;            // kΩ × µF = ms
  const T = 5 * tau;
  s.tt = ((s.tt || 0) + dt / 6) % 1.15;
  const tm = Math.min(s.tt, 1) * T;
  const pts = []; for (let i = 0; i <= 80; i++) { const x = T * i / 80; pts.push([x, s.Vs * (1 - Math.exp(-x / tau))]); }
  const g = graph(ctx, 50, 30, w - 80, h - 90, [{ pts }], { xmin: 0, xmax: T, ymin: 0, ymax: s.Vs, xlabel: 'time (ms)', ylabel: 'Vc (V)', cursor: tm });
  const vc = s.Vs * (1 - Math.exp(-tm / tau));
  ctx.fillStyle = colors.accent2; ctx.beginPath(); ctx.arc(g.X(tm), g.Y(vc), 6, 0, TAU); ctx.fill();
  ctx.strokeStyle = colors.mute; ctx.setLineDash([3, 4]); ctx.beginPath();
  ctx.moveTo(g.X(tau), g.Y(0)); ctx.lineTo(g.X(tau), g.Y(.632 * s.Vs)); ctx.lineTo(g.X(0), g.Y(.632 * s.Vs)); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = colors.text; ctx.font = '12px JetBrains Mono, monospace';
  ctx.fillText('τ = RC → 63.2%', g.X(tau) + 6, g.Y(.632 * s.Vs) + 16);
  ctx.fillText(`t = ${fmt(tm, 1)} ms   Vc = ${fmt(vc, 2)} V`, 56, h - 16);
}

export const CONCEPTS = [
  {
    id: 'engine', name: 'Four-stroke engine', branch: 'MECH · AUTO', lab3d: '#/4d',
    desc: 'The Otto cycle on a slider-crank mechanism. One cycle takes two crank revolutions (720°).',
    params: [{ id: 'speed', label: 'Crank speed', min: 20, max: 540, step: 10, val: 120, unit: '°/s' }],
    init: s => { s.angle = 0; },
    draw(ctx, w, h, s, t, dt) { s.angle = (s.angle + s.speed * dt) % 720; engine2D(ctx, w, h, s); },
    info(s) { const st = strokeAt(s.angle || 0); return `<p><b style="color:${st[3]}">${st[0]}</b> — ${st[4]}</p><p class="muted">Piston position uses the exact slider-crank relation y = r·cosθ + √(l² − r²·sin²θ).</p>`; },
  },
  {
    id: 'gears', name: 'Gear train', branch: 'MECH', desc: 'Two meshing spur gears: speed, torque and direction change with tooth count.',
    params: [{ id: 'n1', label: 'Driver teeth', min: 8, max: 40, step: 1, val: 16 }, { id: 'n2', label: 'Driven teeth', min: 8, max: 60, step: 1, val: 32 }, { id: 'rpm', label: 'Driver speed', min: 5, max: 120, step: 1, val: 30, unit: ' rpm' }],
    draw: gearsDraw,
    info(s) { const i = s.n2 / s.n1; return `<dl class="kv"><dt>Gear ratio</dt><dd>${fmt(i, 3)} : 1</dd><dt>Driven speed</dt><dd>${fmt(s.rpm / i, 2)} rpm (reversed)</dd><dt>Torque ×</dt><dd>${fmt(i, 3)} (ideal, no losses)</dd><dt>Centre distance</dt><dd>${fmt((s.n1 + s.n2) / 2, 1)} modules</dd></dl>`; },
  },
  {
    id: 'neural', name: 'Neural network', branch: 'AI/ML · CSE', desc: 'Forward pass through a small network. Change the inputs and watch activations propagate.',
    params: [{ id: 'x1', label: 'Input x₁', min: -1, max: 1, step: .05, val: .8 }, { id: 'x2', label: 'Input x₂', min: -1, max: 1, step: .05, val: -.4 }, { id: 'x3', label: 'Input x₃', min: -1, max: 1, step: .05, val: .3 }],
    draw: nnDraw,
    info(s) { const o = nnForward([s.x1, s.x2, s.x3]).acts.at(-1); return `<p>Outputs: <b>${o.map(v => fmt(v, 3)).join(', ')}</b></p><p class="muted">Weights are fixed random demo values and the network is <b>untrained</b>. The activations are real tanh computations. Orange = positive, blue = negative.</p>`; },
  },
  {
    id: 'beam', name: 'Beam bending', branch: 'CIVIL · MECH', desc: 'Simply supported beam with a central point load (Euler–Bernoulli theory).',
    params: [{ id: 'P', label: 'Load P', min: 1, max: 100, step: 1, val: 20, unit: ' kN' }, { id: 'L', label: 'Span L', min: 1, max: 10, step: .1, val: 4, unit: ' m' }, { id: 'E', label: 'Young’s modulus E', min: 10, max: 210, step: 5, val: 200, unit: ' GPa' }, { id: 'I', label: 'Second moment I', min: 1000, max: 100000, step: 500, val: 20000, unit: ' cm⁴' }],
    draw: beamDraw,
    info(s) { const c = beamCalc(s), lim = s.L * 1000 / 360; return `<dl class="kv"><dt>Reactions</dt><dd>${fmt(c.R, 2)} kN each</dd><dt>Max moment</dt><dd>${fmt(c.M, 2)} kN·m</dd><dt>Max deflection</dt><dd>${fmt(c.d, 2)} mm</dd><dt>L/360 limit</dt><dd>${fmt(lim, 2)} mm — ${c.d <= lim ? '<span style="color:var(--ok)">OK</span>' : '<span style="color:var(--danger)">exceeded</span>'}</dd></dl><p class="muted">δmax = P·L³ / (48·E·I)</p>`; },
  },
  {
    id: 'rc', name: 'RC charging circuit', branch: 'ECE · EEE', desc: 'Capacitor charging through a resistor: Vc(t) = Vs·(1 − e^(−t/RC)).',
    params: [{ id: 'R', label: 'Resistance', min: 1, max: 100, step: 1, val: 10, unit: ' kΩ' }, { id: 'C', label: 'Capacitance', min: 1, max: 1000, step: 1, val: 47, unit: ' µF' }, { id: 'Vs', label: 'Supply Vs', min: 1, max: 24, step: .5, val: 12, unit: ' V' }],
    draw: rcDraw,
    info(s) { const tau = s.R * s.C; return `<dl class="kv"><dt>Time constant τ</dt><dd>${fmt(tau, 2)} ms</dd><dt>Reaches 99%</dt><dd>≈ ${fmt(4.6 * tau, 1)} ms</dd><dt>Initial current</dt><dd>${fmt(s.Vs / s.R, 3)} mA</dd></dl>`; },
  },
];
