// Static catalogue data: branches and courses.
export const BRANCHES = [
  ['cse', 'CSE', 'Computer Science Engineering'], ['aiml', 'AI/ML', 'Artificial Intelligence & Machine Learning'],
  ['ds', 'DS', 'Data Science'], ['it', 'IT', 'Information Technology'],
  ['ece', 'ECE', 'Electronics & Communication Engineering'], ['eee', 'EEE', 'Electrical & Electronics Engineering'],
  ['mech', 'MECH', 'Mechanical Engineering'], ['civil', 'CIVIL', 'Civil Engineering'],
  ['chem', 'CHEM', 'Chemical Engineering'], ['aero', 'AERO', 'Aerospace Engineering'],
  ['auto', 'AUTO', 'Automobile Engineering'], ['robo', 'ROBO', 'Robotics & Automation'],
  ['mecha', 'MECHA', 'Mechatronics Engineering'], ['bme', 'BME', 'Biomedical Engineering'],
  ['biotech', 'BIOTECH', 'Biotechnology'], ['env', 'ENV', 'Environmental Engineering'],
  ['ie', 'IE', 'Industrial Engineering'],
].map(([id, short, name]) => ({ id, short, name }));

// [branch, title, level, lessons, visualLabs, relatedLab]
const LV = { B: 'Beginner', I: 'Intermediate', A: 'Advanced' };
const RAW = [
  ['cse', 'Data Structures & Algorithms', 'I', 64, 18], ['cse', 'Operating Systems', 'I', 48, 10], ['cse', 'Computer Networks', 'I', 40, 12],
  ['aiml', 'Neural Networks', 'A', 52, 16, '#/visual-lab?c=neural'], ['aiml', 'Supervised Learning', 'I', 38, 11],
  ['ds', 'Statistics for Engineers', 'B', 34, 9], ['ds', 'Data Visualisation', 'B', 28, 14],
  ['it', 'Web Technologies', 'B', 42, 8], ['it', 'Database Systems', 'I', 45, 7],
  ['ece', 'Analog Electronics', 'I', 50, 15, '#/visual-lab?c=rc'], ['ece', 'Digital Logic Design', 'B', 40, 13], ['ece', 'Antennas & Wave Propagation', 'A', 32, 9],
  ['eee', 'Electrical Machines', 'I', 46, 14], ['eee', 'Power Systems', 'A', 50, 11],
  ['mech', 'Thermodynamics', 'I', 54, 17, '#/4d'], ['mech', 'Theory of Machines', 'I', 44, 19, '#/visual-lab?c=gears'], ['mech', 'Fluid Mechanics', 'A', 40, 12, '#/simulations?s=venturi'],
  ['civil', 'Structural Analysis', 'A', 48, 15, '#/visual-lab?c=beam'], ['civil', 'Strength of Materials', 'I', 45, 13, '#/visual-lab?c=beam'],
  ['chem', 'Mass Transfer', 'I', 38, 8], ['chem', 'Process Control', 'A', 34, 9],
  ['aero', 'Aerodynamics', 'A', 44, 14], ['aero', 'Flight Mechanics', 'A', 36, 10, '#/simulations?s=projectile'],
  ['auto', 'IC Engines', 'I', 40, 16, '#/visual-lab?c=engine'], ['auto', 'Vehicle Dynamics', 'A', 32, 10],
  ['robo', 'Robot Kinematics', 'A', 38, 15, '#/simulations?s=arm'], ['robo', 'PLC & Industrial Automation', 'I', 34, 9],
  ['mecha', 'Sensors & Actuators', 'B', 32, 12], ['mecha', 'Embedded Control', 'I', 36, 10],
  ['bme', 'Biomedical Instrumentation', 'I', 36, 9], ['bme', 'Biomechanics', 'A', 30, 11],
  ['biotech', 'Bioprocess Engineering', 'I', 36, 7], ['biotech', 'Molecular Biology', 'B', 34, 8],
  ['env', 'Water Treatment', 'I', 32, 8], ['env', 'Air Pollution Control', 'I', 28, 6],
  ['ie', 'Operations Research', 'I', 38, 6], ['ie', 'Lean Manufacturing', 'B', 26, 7],
];
export const COURSES = RAW.map(([branch, title, lv, lessons, labs, lab]) => ({
  id: branch + '-' + title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
  branch, title, level: LV[lv], lessons, labs, lab: lab || null,
}));

export const LABS = [
  ['#/visual-lab', 'Visual Learning Lab', 'See engines, gear trains, neural nets, beams and circuits explained visually.', '◉'],
  ['#/3d-lab', '3D Lab', 'Rotate, explode, section and measure engineering models in WebGL.', '◈'],
  ['#/4d', '4D Visualization', '3D space + time: scrub through engine cycles, assemblies and robot motion.', '⏱'],
  ['#/simulations', 'Simulations', 'Tune parameters and watch pendulums, circuits and thermodynamic cycles respond.', '∿'],
  ['#/project-studio', 'Project Studio', 'Turn an idea into a structured plan, components, tests and documentation.', '✦'],
  ['#/graphic-studio', 'Graphic Design Studio', 'Draw circuit diagrams, flowcharts and posters on a layered canvas.', '✎'],
  ['#/printing-lab', '3D Printing Lab', 'Inspect STL/OBJ models and learn slicing, infill, supports and orientation.', '⬡'],
  ['#/ai-tutor', 'VIZ AI', 'Engineering tutor, doubt solver and project mentor (bring your own AI key).', '✧'],
  ['#/exam', 'Exam Preparation', 'Step-by-step numerical solver, AI doubts and a practice quiz.', '✓'],
];
