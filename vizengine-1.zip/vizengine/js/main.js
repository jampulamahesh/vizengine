import { $, $$, esc, store, save, trackVisit, refreshColors } from './util.js';

const NAV = [
  ['Learn', [['home', 'Home', '⌂'], ['courses', 'Engineering Courses', '▤'], ['exam', 'Exam Preparation', '✓'], ['ai-tutor', 'VIZ AI', '✧']]],
  ['Visualize', [['visual-lab', 'Visual Learning Lab', '◉'], ['3d-lab', '3D Lab', '◈'], ['4d', '4D Visualization', '⏱'], ['simulations', 'Simulations', '∿']]],
  ['Create', [['project-studio', 'Project Studio', '✦'], ['graphic-studio', 'Graphic Design Studio', '✎'], ['printing-lab', '3D Printing Lab', '⬡']]],
  ['You', [['my-projects', 'My Projects', '▣'], ['dashboard', 'Dashboard', '▥'], ['community', 'Community', '☍']]],
];

const PAGES = {
  home: () => import('./pages/home.js'),
  courses: () => import('./pages/courses.js'),
  'visual-lab': () => import('./pages/visual.js'),
  '3d-lab': () => import('./pages/lab3d.js'),
  '4d': () => import('./pages/lab4d.js'),
  simulations: () => import('./pages/sims.js'),
  'project-studio': () => import('./pages/project.js'),
  'graphic-studio': () => import('./pages/graphic.js'),
  'printing-lab': () => import('./pages/printing.js'),
  'ai-tutor': () => import('./pages/tutor.js'),
  exam: () => import('./pages/exam.js'),
  community: () => import('./pages/community.js'),
  'my-projects': () => import('./pages/projects.js'),
  dashboard: () => import('./pages/dashboard.js'),
  auth: () => import('./pages/auth.js'),
};

const side = $('#side'), view = $('#view'), top = $('#topbar');

side.innerHTML = `<a class="brand" href="#/home"><i>V</i>VIZENGINE</a>` +
  NAV.map(([g, items]) => `<div class="nav-group">${g}</div>` + items.map(([k, n, i]) => `<a class="nav" data-k="${k}" href="#/${k}"><span>${i}</span>${n}</a>`).join('')).join('');

top.innerHTML = `<button class="btn sm ghost" id="menuBtn" aria-label="Menu">☰ Menu</button>
  <div class="tag-line">Learn → Visualize → Simulate → Create → Build</div>
  <button class="btn sm ghost" id="themeBtn" aria-label="Toggle theme">◐ Theme</button>
  <a class="btn sm" href="#/auth">Sign in</a>`;

function setTheme(t) {
  document.documentElement.dataset.theme = t; save('theme', t);
  refreshColors();
}
setTheme(store('theme', 'dark'));
$('#themeBtn').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
$('#menuBtn').onclick = () => document.body.classList.toggle('menu-open');
$('#scrim').onclick = () => document.body.classList.remove('menu-open');

let cleanup = null, token = 0;
async function route() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, qs] = raw.split('?');
  const key = path || 'home';
  const my = ++token;
  document.body.classList.remove('menu-open');
  try { cleanup && cleanup(); } catch (e) { console.error(e); }
  cleanup = null;
  $$('.side a.nav').forEach(a => a.classList.toggle('active', a.dataset.k === key));
  const load = PAGES[key];
  if (!load) { view.innerHTML = `<div class="empty"><h2>Page not found</h2><p><a href="#/home">Back to home</a></p></div>`; return; }
  view.innerHTML = '<div class="loading">Loading…</div>';
  try {
    const mod = await load();
    if (my !== token) return;
    view.innerHTML = '';
    trackVisit(key);
    const c = await mod.default(view, new URLSearchParams(qs || ''));
    if (my !== token) { c && c(); return; }
    cleanup = typeof c === 'function' ? c : null;
    document.title = (NAV.flatMap(g => g[1]).find(i => i[0] === key)?.[1] || 'VIZENGINE') + ' — VIZENGINE';
  } catch (e) {
    console.error(e);
    if (my !== token) return;
    const cdn = /three|fetch|import|Failed to load|module/i.test(String(e && e.message));
    view.innerHTML = `<div class="notice warn"><b>This page could not load.</b><br>${cdn ? 'The 3D engine (Three.js) is loaded from cdn.jsdelivr.net, so this page needs an internet connection and a browser with WebGL.' : ''}<br><code>${esc(e && e.message || e)}</code></div>`;
  }
  window.scrollTo(0, 0);
}
addEventListener('hashchange', route);
route();
