// Procedural engineering models (Three.js). 1 scene unit = 10 mm (educational scale).
import * as THREE from 'three';

const M = (color, metalness = 0.6, roughness = 0.35, extra = {}) => new THREE.MeshStandardMaterial({ color, metalness, roughness, ...extra });
const mesh = (geo, mat) => new THREE.Mesh(geo, mat);

// A "part" owns a wrapper group (moved by the explode slider) and a list of meshes (for visibility, highlight, clipping).
function part(name, obj, meshes, dir, material, note) {
  const p = { name, obj, meshes, dir: new THREE.Vector3(...dir), material, note, home: obj.position.clone() };
  meshes.forEach(m => { m.userData.part = p; });
  return p;
}

export function gearGeometry(n, R, root, depth, hole) {
  const sh = new THREE.Shape(), p = Math.PI * 2 / n;
  for (let i = 0; i < n; i++) {
    [[root, 0], [R, .15], [R, .45], [root, .6]].forEach(([r, f], j) => {
      const a = i * p + f * p, x = Math.cos(a) * r, y = Math.sin(a) * r;
      (i === 0 && j === 0) ? sh.moveTo(x, y) : sh.lineTo(x, y);
    });
  }
  sh.closePath();
  const h = new THREE.Path(); h.absarc(0, 0, hole, 0, Math.PI * 2, true); sh.holes.push(h);
  const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: false });
  g.translate(0, 0, -depth / 2);
  return g;
}
function ringGeometry(ro, ri, depth) {
  const sh = new THREE.Shape(); sh.absarc(0, 0, ro, 0, Math.PI * 2, false);
  const h = new THREE.Path(); h.absarc(0, 0, ri, 0, Math.PI * 2, true); sh.holes.push(h);
  const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: false, curveSegments: 32 });
  g.translate(0, 0, -depth / 2); return g;
}

/* ---------- 1. Cube ---------- */
function buildCube() {
  const group = new THREE.Group(), parts = [];
  let i = 1;
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) {
    const w = new THREE.Group(); w.position.set(sx * .5, 1 + sy * .5, sz * .5);
    const m = mesh(new THREE.BoxGeometry(.96, .96, .96), M(0x4aa3ff, .3, .4)); w.add(m);
    const e = new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry), new THREE.LineBasicMaterial({ color: 0x0a1624 })); w.add(e);
    group.add(w);
    parts.push(part('Cell ' + i++, w, [m], [sx, sy, sz].map(v => v * 0.9), 'Aluminium 6061 (demo)', 'One of eight cells that make up a 2×2×2 cube (20 mm edge). Use it to see how Explode and Section work.'));
  }
  return { group, parts, params: [], update() { }, focus: [0, 1, 0] };
}

/* ---------- 2. Gear on shaft ---------- */
function buildGear() {
  const group = new THREE.Group(), parts = [];
  const mk = (name, geo, mat, pos, dir, material, note, rotate = true) => {
    const w = new THREE.Group(); w.position.set(...pos); const m = mesh(geo, mat); w.add(m); group.add(w);
    const p = part(name, w, [m], dir, material, note); p.spin = rotate; parts.push(p); return p;
  };
  const prof = [[0, -1.8], [.45, -1.8], [.45, -1.2], [.3, -1.2], [.3, 1.9], [0, 1.9]].map(([r, y]) => new THREE.Vector2(r, y));
  const sg = new THREE.LatheGeometry(prof, 40); sg.rotateX(Math.PI / 2);
  mk('Shaft', sg, M(0x9aa7b8, .9, .25), [0, 1.3, 0], [0, 0, 0], 'Steel EN8 (C45)', 'Stepped shaft. The shoulder locates the gear axially; the 6 mm radius journal carries the gear bore.');
  mk('Spur gear', gearGeometry(18, 1.2, 1.0, .5, .32), M(0x35e0c2, .7, .3), [0, 1.3, 0], [0, 0, 2.2], 'Steel 20MnCr5 (case hardened)', '18-tooth spur gear: outer radius 12 mm, root radius 10 mm, face width 5 mm.');
  mk('Washer', ringGeometry(.6, .32, .08), M(0xcfd8e3, .8, .3), [0, 1.3, .35], [0, 0, 3.2], 'Zinc-plated steel', 'Spreads the nut clamping load over the gear face.');
  const nut = new THREE.CylinderGeometry(.5, .5, .3, 6); nut.rotateX(Math.PI / 2);
  mk('Lock nut', nut, M(0xffb547, .8, .3), [0, 1.3, .6], [0, 0, 4.2], 'Steel grade 8', 'Hex nut that retains the assembly on the threaded shaft end.');
  return { group, parts, params: [], focus: [0, 1.3, 0], update(st) { const a = st.angle * Math.PI / 180 * 0.5; parts.forEach(p => { p.obj.rotation.z = a; }); } };
}

/* ---------- 3. Shaft with bearings & pulley ---------- */
function buildShaft() {
  const group = new THREE.Group(), parts = [];
  const add = (name, geo, mat, pos, dir, material, note, rot) => {
    const w = new THREE.Group(); w.position.set(...pos); const m = mesh(geo, mat); w.add(m); group.add(w);
    const p = part(name, w, [m], dir, material, note); p.spin = rot; parts.push(p); return p;
  };
  const prof = [[0, -2.6], [.35, -2.6], [.35, -1.7], [.5, -1.7], [.5, 1.7], [.35, 1.7], [.35, 2.6], [0, 2.6]].map(([r, y]) => new THREE.Vector2(r, y));
  const sg = new THREE.LatheGeometry(prof, 40); sg.rotateZ(-Math.PI / 2);
  add('Shaft', sg, M(0x9aa7b8, .9, .25), [0, 1.2, 0], [0, 0, 0], 'Steel C45', 'Stepped transmission shaft (Ø10 / Ø7 mm) carrying a pulley between two bearings.', true);
  [-1, 1].forEach(s => {
    const g = ringGeometry(.8, .5, .5); g.rotateY(Math.PI / 2);
    add(s < 0 ? 'Bearing (left)' : 'Bearing (right)', g, M(0x4aa3ff, .8, .3), [s * 1.35, 1.2, 0], [s * 1.8, 0, 0], 'Chrome steel 52100', 'Deep-groove ball bearing seat (simplified as a ring).', false);
  });
  const pg = ringGeometry(1.1, .5, .5); pg.rotateY(Math.PI / 2);
  add('Pulley', pg, M(0xffb547, .5, .4), [0, 1.2, 0], [0, 1.9, 0], 'Cast aluminium', 'V-belt pulley, pressed onto the shaft shoulder.', true);
  return { group, parts, params: [], focus: [0, 1.2, 0], update(st) { const a = st.angle * Math.PI / 180; parts.forEach(p => { if (p.spin) p.obj.rotation.x = a; }); } };
}

/* ---------- 4. Single-cylinder engine ---------- */
const R_CRANK = .5, L_ROD = 1.7;
export function buildEngine() {
  const group = new THREE.Group(), parts = [];
  const wrap = (name, dir, material, note) => { const w = new THREE.Group(); group.add(w); w.userData = { name, dir, material, note }; return w; };
  const reg = (w, meshes) => { const d = w.userData; const p = part(d.name, w, meshes, d.dir, d.material, d.note); parts.push(p); return p; };
  const baseY = 0;

  // liner (block)
  const wLiner = wrap('Cylinder block', [2.4, 0, 0], 'Grey cast iron', 'Bore Ø12.4 mm. Shown semi-transparent so the piston is visible.');
  const lg = ringGeometry(.86, .63, 1.9); lg.rotateX(-Math.PI / 2);
  const liner = mesh(lg, M(0x6b7a90, .7, .5, { transparent: true, opacity: .35, side: THREE.DoubleSide })); liner.position.y = 1.75; wLiner.add(liner); reg(wLiner, [liner]);

  // head + plug
  const wHead = wrap('Cylinder head', [0, 1.7, 0], 'Aluminium alloy', 'Closes the cylinder and carries the valves and spark plug.');
  const head = mesh(new THREE.CylinderGeometry(.9, .9, .36, 40), M(0x8795a8, .6, .4)); head.position.y = 2.88; wHead.add(head);
  const plug = mesh(new THREE.CylinderGeometry(.09, .09, .5, 16), M(0xe8edf5, .2, .5)); plug.position.set(0, 3.2, 0); wHead.add(plug);
  reg(wHead, [head, plug]);

  // valves
  const wValves = wrap('Valves', [-2.0, 2.2, 0], 'Heat-resistant steel', 'Intake (left) opens during the intake stroke; exhaust (right) opens during the exhaust stroke.');
  const mkValve = x => { const g = new THREE.Group(); g.position.set(x, 2.72, 0); const stem = mesh(new THREE.CylinderGeometry(.04, .04, .7, 12), M(0xcfd8e3, .9, .2)); stem.position.y = .3; const disc = mesh(new THREE.CylinderGeometry(.2, .2, .05, 20), M(0x35e0c2, .8, .3)); g.add(stem, disc); wValves.add(g); return { g, ms: [stem, disc] }; };
  const vi = mkValve(-.34), ve = mkValve(.34);
  reg(wValves, [...vi.ms, ...ve.ms]);

  // flash
  const flash = mesh(new THREE.SphereGeometry(.5, 20, 16), new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0, depthWrite: false }));
  flash.visible = false; group.add(flash);

  // piston assembly
  const wPist = wrap('Piston', [-2.2, 0.8, 0], 'Forged aluminium', 'Slides in the bore. Its position follows the exact slider-crank equation.');
  const pg = new THREE.Group(); wPist.add(pg);
  const pcyl = mesh(new THREE.CylinderGeometry(.6, .6, .62, 32), M(0xb9c4d4, .7, .3)); pcyl.position.y = .08;
  const pin = mesh(new THREE.CylinderGeometry(.09, .09, .9, 16), M(0x35e0c2, .8, .3)); pin.rotation.x = Math.PI / 2;
  pg.add(pcyl, pin); reg(wPist, [pcyl, pin]);

  // connecting rod
  const wRod = wrap('Connecting rod', [0, -1.4, 1.5], 'Forged steel (I-section)', 'Links piston pin to crank pin and converts linear motion to rotation.');
  const rg = new THREE.Group(); wRod.add(rg);
  const rbar = mesh(new THREE.BoxGeometry(.14, L_ROD, .16), M(0xffb547, .7, .35)); rg.add(rbar);
  const big = mesh(new THREE.CylinderGeometry(.2, .2, .2, 20), M(0xffb547, .7, .35)); big.rotation.x = Math.PI / 2; big.position.y = -L_ROD / 2; rg.add(big);
  const small = mesh(new THREE.CylinderGeometry(.13, .13, .2, 20), M(0xffb547, .7, .35)); small.rotation.x = Math.PI / 2; small.position.y = L_ROD / 2; rg.add(small);
  rg.position.z = 0.12;
  reg(wRod, [rbar, big, small]);

  // crankshaft
  const wCrank = wrap('Crankshaft', [0, -1.7, -.6], 'Forged steel', 'Crank radius 5 mm gives a 10 mm stroke. The counterweight balances the reciprocating mass.');
  const cg = new THREE.Group(); wCrank.add(cg);
  const web = mesh(new THREE.CylinderGeometry(.62, .62, .14, 36), M(0x6b7a90, .8, .3)); web.rotation.x = Math.PI / 2; web.position.z = .1;
  const cpin = mesh(new THREE.CylinderGeometry(.14, .14, .3, 20), M(0x35e0c2, .8, .3)); cpin.rotation.x = Math.PI / 2; cpin.position.set(0, R_CRANK, .12);
  const cw = mesh(new THREE.BoxGeometry(.8, .5, .2), M(0x9aa7b8, .8, .3)); cw.position.set(0, -.42, .1);
  const shaft = mesh(new THREE.CylinderGeometry(.16, .16, 1.4, 20), M(0xcfd8e3, .9, .2)); shaft.rotation.x = Math.PI / 2; shaft.position.z = -.2;
  cg.add(web, cpin, cw, shaft); reg(wCrank, [web, cpin, cw, shaft]);

  // flywheel
  const wFly = wrap('Flywheel', [0, -.6, -2.2], 'Cast iron', 'Stores rotational energy to smooth out the power-stroke pulses.');
  const fg = new THREE.Group(); wFly.add(fg);
  const fl = mesh(new THREE.CylinderGeometry(.95, .95, .22, 48), M(0x4a5870, .8, .4)); fl.rotation.x = Math.PI / 2; fl.position.z = -.7;
  const fm = mesh(new THREE.BoxGeometry(.2, .16, .26), M(0xff6b4a, .5, .4)); fm.position.set(.8, 0, -.7); fg.add(fl, fm);
  reg(wFly, [fl, fm]);

  const model = {
    group, parts, flash, focus: [0, 1.6, 0], params: [],
    update(st) {
      const a = ((st.angle % 720) + 720) % 720, th = a * Math.PI / 180;
      const yp = R_CRANK * Math.cos(th) + Math.sqrt(L_ROD ** 2 - (R_CRANK * Math.sin(th)) ** 2);
      pg.position.y = yp;
      const cx = R_CRANK * Math.sin(th), cy = R_CRANK * Math.cos(th);
      const dx = 0 - cx, dy = yp - cy, len = Math.hypot(dx, dy);
      rg.position.set(cx + dx / 2, cy + dy / 2, rg.position.z);
      rg.rotation.z = Math.atan2(-dx, dy);
      cg.rotation.z = -th; fg.rotation.z = -th;
      const lift = (on, s) => on ? .16 * Math.sin(Math.PI * (a - s) / 180) : 0;
      vi.g.position.y = 2.72 - lift(a < 180, 0);
      ve.g.position.y = 2.72 - lift(a >= 540, 540);
      if (a >= 360 && a < 450) {
        const f = 1 - (a - 360) / 90;
        flash.visible = true; flash.material.opacity = .85 * f; flash.scale.setScalar(.7 + .5 * (1 - f));
        flash.position.set(0, yp + .78, 0).add(wPist.position);
      } else flash.visible = false;
    },
  };
  return model;
}

/* ---------- 5. Robot arm ---------- */
function buildRobot() {
  const group = new THREE.Group(), parts = [];
  const mat1 = M(0x35e0c2, .5, .35), mat2 = M(0x4aa3ff, .5, .35), mat3 = M(0xffb547, .5, .35), dark = M(0x39465c, .7, .4);

  const base = new THREE.Group(); group.add(base);
  const bm = mesh(new THREE.CylinderGeometry(.9, 1.0, .35, 40), dark); bm.position.y = .175; base.add(bm);
  parts.push(part('Base', base, [bm], [0, -.5, 0], 'Cast aluminium', 'Fixed pedestal bolted to the work surface.'));

  const turret = new THREE.Group(); turret.position.y = .35; group.add(turret);
  const tm = mesh(new THREE.CylinderGeometry(.55, .65, .3, 32), mat1); tm.position.y = .15;
  const l1 = mesh(new THREE.BoxGeometry(.4, 1.3, .4), mat1); l1.position.y = .95;
  turret.add(tm, l1);
  parts.push(part('Turret & upper column', turret, [tm, l1], [0, .6, 0], 'Aluminium 6061', 'Joint 1 rotates this column about the vertical axis (base yaw).'));

  const shoulder = new THREE.Group(); shoulder.position.set(0, 1.6, 0); turret.add(shoulder);
  const sj = mesh(new THREE.SphereGeometry(.3, 24, 16), dark);
  const l2 = mesh(new THREE.BoxGeometry(.32, 1.5, .32), mat2); l2.position.y = .75;
  shoulder.add(sj, l2);
  parts.push(part('Shoulder joint & lower arm', shoulder, [sj, l2], [0, .7, 0], 'Aluminium 6061', 'Joint 2 (shoulder pitch) swings the lower arm.'));

  const elbow = new THREE.Group(); elbow.position.set(0, 1.5, 0); shoulder.add(elbow);
  const ej = mesh(new THREE.SphereGeometry(.25, 24, 16), dark);
  const l3 = mesh(new THREE.BoxGeometry(.26, 1.1, .26), mat3); l3.position.y = .55;
  elbow.add(ej, l3);
  parts.push(part('Elbow joint & forearm', elbow, [ej, l3], [0, .7, 0], 'Aluminium 6061', 'Joint 3 (elbow pitch) swings the forearm.'));

  const grip = new THREE.Group(); grip.position.set(0, 1.1, 0); elbow.add(grip);
  const gm = [-.13, .13].map(x => { const f = mesh(new THREE.BoxGeometry(.06, .35, .2), dark); f.position.set(x, .17, 0); grip.add(f); return f; });
  const wr = mesh(new THREE.BoxGeometry(.4, .12, .24), mat3); grip.add(wr);
  parts.push(part('Gripper', grip, [...gm, wr], [0, 1.0, 0], 'ABS + steel pads', 'Parallel-jaw end effector.'));

  const tip = new THREE.Object3D(); tip.position.set(0, .35, 0); grip.add(tip);
  const model = {
    group, parts, focus: [0, 2, 0], tip,
    params: [
      { id: 'j1', label: 'Joint 1 · base yaw', min: -180, max: 180, step: 1, val: 20, unit: '°' },
      { id: 'j2', label: 'Joint 2 · shoulder', min: -90, max: 90, step: 1, val: 30, unit: '°' },
      { id: 'j3', label: 'Joint 3 · elbow', min: -120, max: 120, step: 1, val: -45, unit: '°' },
    ],
    update(st) {
      turret.rotation.y = st.j1 * Math.PI / 180;
      shoulder.rotation.z = -st.j2 * Math.PI / 180;
      elbow.rotation.z = -st.j3 * Math.PI / 180;
    },
    tipPosition() { group.updateMatrixWorld(true); return tip.getWorldPosition(new THREE.Vector3()); },
  };
  return model;
}

export const MODELS = [
  { id: 'cube', name: 'Cube', blurb: 'Eight cells, ideal for learning the viewer controls.', build: buildCube },
  { id: 'gear', name: 'Gear on shaft', blurb: 'Spur gear, shaft, washer and nut.', build: buildGear },
  { id: 'shaft', name: 'Shaft & bearings', blurb: 'Stepped shaft with two bearings and a pulley.', build: buildShaft },
  { id: 'engine', name: 'Engine', blurb: 'Single-cylinder four-stroke with working valves.', build: buildEngine },
  { id: 'robot', name: 'Robot arm', blurb: '3-axis arm with live forward kinematics.', build: buildRobot },
];

// staggered assembly: t in [0,1] — part i is fully in place when t >= (i+1)/N
export function applyAssembly(model, t, spread = 1) {
  const N = model.parts.length;
  model.parts.forEach((p, i) => {
    const prog = Math.min(1, Math.max(0, t * N - i));
    const e = 1 - (prog * prog * (3 - 2 * prog));
    p.obj.position.copy(p.home).addScaledVector(p.dir, e * 1.6 * spread);
    p.meshes.forEach(m => { m.visible = prog > 0; });
  });
}
