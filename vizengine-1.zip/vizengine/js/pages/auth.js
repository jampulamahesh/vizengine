export default function (root) {
  root.innerHTML = `<div class="page-head"><span class="tag warn">NO BACKEND YET</span><h1 style="font-size:2rem;margin-top:8px">Sign in</h1></div>
  <div class="panel" style="max-width:420px"><div class="notice warn" style="margin-top:0"><b>Accounts aren't enabled.</b> This site has no server, so it cannot verify passwords or sync data, and the form below is disabled on purpose. Everything you do is stored in this browser.</div>
  <label class="f">Email</label><input type="text" disabled placeholder="you@college.edu"><label class="f">Password</label><input type="password" disabled>
  <button class="btn primary" disabled style="margin-top:12px">Sign in (not available)</button>
  <p class="muted" style="margin-top:14px;font-size:.85rem">Developers: wire this page to Supabase Auth or Firebase Auth and replace localStorage with a database.</p></div>`;
}
