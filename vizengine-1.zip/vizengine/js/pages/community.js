export default function (root) {
  root.innerHTML = `<div class="page-head"><span class="tag warn">NEEDS A BACKEND</span><h1 style="font-size:2rem;margin-top:8px">Community</h1>
  <p>Sharing projects, discussions and peer review need user accounts and a database, which this static site doesn't include, so nothing is pretended here.</p></div>
  <div class="grid auto">
    <div class="card"><h3>Planned: project showcase</h3><p>Publish a saved project plan and let others comment.</p></div>
    <div class="card"><h3>Planned: doubt forum</h3><p>Ask and answer engineering questions by branch.</p></div>
    <div class="card"><h3>Planned: team spaces</h3><p>Shared project boards for final-year teams.</p></div></div>
  <div class="notice" style="margin-top:20px">To add this: connect Supabase or Firebase (auth + database), then replace this page. Meanwhile, export plans from <a href="#/my-projects">My Projects</a> and share the Markdown file.</div>`;
}
