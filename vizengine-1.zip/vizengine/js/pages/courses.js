import { BRANCHES, COURSES } from '../data.js';
import { $, $$, esc, store, save } from '../util.js';

export default function (root, q) {
  let branch = BRANCHES.some(b => b.id === q.get('branch')) ? q.get('branch') : 'all', level = 'All', text = '';
  let prog = store('progress', {});
  root.innerHTML = `
  <div class="page-head"><span class="tag">ENGINEERING COURSES</span><h1 style="font-size:2rem;margin-top:8px">Engineering Courses</h1>
  <p>Each subject is planned with chapters, lessons, visual explanations, simulations, quizzes and exam questions. Courses marked “curriculum in preparation” have a catalogue entry but no lesson content yet.</p></div>
  <div class="toolbar" style="margin-bottom:10px"><input type="search" id="s" placeholder="Search courses…" style="max-width:280px"><select id="b" style="max-width:340px"><option value="all">All branches</option>${BRANCHES.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('')}</select>
    ${['All', 'Beginner', 'Intermediate', 'Advanced'].map(l => `<button class="chip ${l === 'All' ? 'active' : ''}" data-l="${l}">${l}</button>`).join('')}<span class="muted" id="n" style="margin-left:auto"></span></div>
  <div class="grid auto" id="grid"></div><dialog id="dlg"></dialog>`;
  $('#b').value = branch;
  const br = id => BRANCHES.find(b => b.id === id);
  function draw() {
    const list = COURSES.filter(c => (branch === 'all' || c.branch === branch) && (level === 'All' || c.level === level) && (c.title + br(c.branch).name).toLowerCase().includes(text));
    $('#n').textContent = list.length + ' courses';
    $('#grid').innerHTML = list.map(c => {
      const enrolled = c.id in prog;
      return `<div class="card"><span class="tag">${br(c.branch).short}</span> <span class="tag warn">${c.level}</span>
      <h3 style="margin-top:10px">${esc(c.title)}</h3><p>${esc(br(c.branch).name)}</p>
      <p style="margin:8px 0">${c.lessons} lessons · ${c.labs} visual labs</p>
      <div class="progress"><i style="width:${prog[c.id] || 0}%"></i></div><p style="font-size:.8rem;margin-top:4px">${enrolled ? `Progress ${prog[c.id]}%` : 'Not enrolled'} · Curriculum in preparation</p>
      <div class="toolbar" style="margin-top:10px"><button class="btn sm ${enrolled ? '' : 'primary'}" data-e="${c.id}">${enrolled ? 'Unenrol' : 'Enrol'}</button>${c.lab ? `<a class="btn sm" href="${c.lab}">Open related lab</a>` : ''}</div></div>`;
    }).join('') || '<div class="empty">No courses match.</div>';
  }
  $('#s').oninput = e => { text = e.target.value.toLowerCase(); draw(); };
  $('#b').onchange = e => { branch = e.target.value; draw(); };
  root.querySelector('.toolbar').addEventListener('click', e => { const b = e.target.closest('[data-l]'); if (b) { level = b.dataset.l; $$('[data-l]').forEach(x => x.classList.toggle('active', x === b)); draw(); } });
  $('#grid').onclick = e => { const b = e.target.closest('[data-e]'); if (!b) return; const id = b.dataset.e; if (id in prog) delete prog[id]; else prog[id] = 0; save('progress', prog); draw(); };
  draw();
}
