import { esc, store } from '../util.js';

const NAMES = { home: 'Home', courses: 'Courses', 'visual-lab': 'Visual Lab', '3d-lab': '3D Lab', '4d': '4D Lab', simulations: 'Simulations', 'project-studio': 'Project Studio', 'graphic-studio': 'Graphic Studio', 'printing-lab': '3D Printing Lab', 'ai-tutor': 'VIZ AI', exam: 'Exam Prep', community: 'Community', 'my-projects': 'My Projects', dashboard: 'Dashboard', auth: 'Sign in' };

export default function (root) {
  const prog = store('progress', {}), projects = store('projects', []), chats = store('chats', []), quiz = store('quiz', []), visits = store('visits', {}), recent = store('recent', []), gfx = store('gfx', []);
  const labs = ['visual-lab', '3d-lab', '4d', 'simulations', 'project-studio', 'graphic-studio', 'printing-lab'];
  const explored = labs.filter(l => visits[l]).length;
  const best = quiz.length ? Math.max(...quiz.map(q => q.score / q.total)) : null;
  const ach = [['First project saved', projects.length > 0], ['Quiz taker', quiz.length > 0], ['Explorer: 5 labs visited', explored >= 5], ['Simulator', !!visits.simulations], ['Doubt solver', !!visits.exam], ['Designer: drew something', gfx.length > 0], ['Course enrolled', Object.keys(prog).length > 0]];
  const stat = (n, l) => `<div class="card"><div style="font-size:2rem;font-weight:700;color:var(--accent)">${n}</div><p>${l}</p></div>`;
  root.innerHTML = `
  <div class="page-head"><span class="tag">DASHBOARD</span><h1 style="font-size:2rem;margin-top:8px">Your learning at a glance</h1>
  <p>Everything here is computed from activity saved in this browser. Sign-in and cloud sync need a backend that isn't connected yet.</p></div>
  <div class="grid auto-s">${stat(Object.keys(prog).length, 'Courses enrolled')}${stat(projects.length, 'Saved projects')}${stat(chats.length, 'AI conversations')}${stat(quiz.length, 'Quizzes taken')}${stat(best == null ? '–' : Math.round(best * 100) + '%', 'Best quiz score')}${stat(explored + ' / ' + labs.length, 'Labs explored')}</div>
  <div class="grid c2" style="margin-top:14px">
    <div class="card"><h3>Recently viewed</h3>${recent.length ? `<div class="list" style="margin-top:8px">${recent.map(r => `<a href="#/${r}" class="btn sm ghost" style="justify-content:flex-start">${esc(NAMES[r] || r)}</a>`).join('')}</div>` : '<p>Nothing yet.</p>'}</div>
    <div class="card"><h3>Achievements</h3><ul style="list-style:none;padding:0;margin:8px 0 0">${ach.map(([n, ok]) => `<li style="padding:4px 0;color:${ok ? 'var(--text)' : 'var(--mute)'}">${ok ? '🏅' : '○'} ${n}</li>`).join('')}</ul></div>
    <div class="card"><h3>Quiz history</h3>${quiz.length ? `<table><tr><th>Date</th><th>Score</th></tr>${quiz.slice().reverse().slice(0, 8).map(q => `<tr><td>${q.date}</td><td>${q.score} / ${q.total}</td></tr>`).join('')}</table>` : '<p>No quizzes yet. Try one in <a href="#/exam">Exam Preparation</a>.</p>'}</div>
    <div class="card"><h3>Saved 3D models</h3><p>Saving 3D models needs file storage, which comes with a backend. Your <a href="#/my-projects">project plans</a> and <a href="#/graphic-studio">drawings</a> are saved locally.</p></div>
  </div>`;
}
