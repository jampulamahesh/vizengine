import { $, $$, esc, fmt, store, save } from '../util.js';
import { AGENTS, askAI, aiReady, md, openAISettings } from '../ai.js';

// ---- Deterministic numerical templates. Each variable lists a JS expression that solves for it (SI units). ----
const T = [
  { id: 'ohm', name: "Ohm's law", rel: 'V = I × R', vars: { V: ['Voltage', 'V', 'I*R'], I: ['Current', 'A', 'V/R'], R: ['Resistance', 'Ω', 'V/I'] } },
  { id: 'kin', name: 'Kinematics: v = u + a·t', rel: 'v = u + a·t', vars: { v: ['Final velocity', 'm/s', 'u+a*t'], u: ['Initial velocity', 'm/s', 'v-a*t'], a: ['Acceleration', 'm/s²', '(v-u)/t'], t: ['Time', 's', '(v-u)/a'] } },
  { id: 'dist', name: 'Kinematics: s = u·t + ½·a·t²', rel: 's = u·t + ½·a·t²', vars: { s: ['Displacement', 'm', 'u*t+0.5*a*t*t'], u: ['Initial velocity', 'm/s', '(s-0.5*a*t*t)/t'], a: ['Acceleration', 'm/s²', '2*(s-u*t)/(t*t)'], t: ['Time', 's', null] } },
  { id: 'stress', name: 'Direct stress: σ = F / A', rel: 'σ = F / A', vars: { sigma: ['Stress σ', 'Pa', 'F/A'], F: ['Force', 'N', 'sigma*A'], A: ['Area', 'm²', 'F/sigma'] } },
  { id: 'hooke', name: 'Elongation: ΔL = F·L / (A·E)', rel: 'ΔL = F·L / (A·E)', vars: { dL: ['Elongation ΔL', 'm', 'F*L/(A*E)'], F: ['Force', 'N', 'dL*A*E/L'], E: ["Young's modulus E", 'Pa', 'F*L/(A*dL)'], L: ['Original length L', 'm', 'dL*A*E/F'], A: ['Area A', 'm²', 'F*L/(dL*E)'] } },
  { id: 'gas', name: 'Ideal gas: P·V = n·R·T', rel: 'P·V = n·R·T  (R = 8.314 J/mol·K)', vars: { P: ['Pressure', 'Pa', 'n*8.314*T/V'], V: ['Volume', 'm³', 'n*8.314*T/P'], n: ['Moles', 'mol', 'P*V/(8.314*T)'], T: ['Temperature', 'K', 'P*V/(n*8.314)'] } },
  { id: 'carnot', name: 'Carnot efficiency: η = 1 − Tc/Th', rel: 'η = 1 − Tc / Th', vars: { eta: ['Efficiency η', '(0–1)', '1-Tc/Th'], Tc: ['Cold reservoir Tc', 'K', 'Th*(1-eta)'], Th: ['Hot reservoir Th', 'K', 'Tc/(1-eta)'] } },
  { id: 'beam', name: 'Beam: δ = P·L³ / (48·E·I)', rel: 'δ = P·L³ / (48·E·I)  (simply supported, central load)', vars: { d: ['Max deflection δ', 'm', 'P*L**3/(48*E*I)'], P: ['Load P', 'N', 'd*48*E*I/L**3'], I: ['Second moment I', 'm⁴', 'P*L**3/(48*E*d)'], E: ['Young\'s modulus E', 'Pa', 'P*L**3/(48*I*d)'], L: ['Span L', 'm', '(d*48*E*I/P)**(1/3)'] } },
  { id: 'power', name: 'Electrical power: P = V·I', rel: 'P = V × I', vars: { P: ['Power', 'W', 'V*I'], V: ['Voltage', 'V', 'P/I'], I: ['Current', 'A', 'P/V'] } },
];
const SYM = { sigma: 'σ', dL: 'ΔL', eta: 'η', d: 'δ' };
const sym = k => SYM[k] || k;

function solve(tpl, target, vals) {
  const [label, unit, expr] = tpl.vars[target];
  if (!expr) return { error: 'This quantity is input-only for this formula.' };
  const names = Object.keys(tpl.vars).filter(k => k !== target && new RegExp('\\b' + k + '\\b').test(expr));
  const missing = names.filter(n => !(n in vals) || isNaN(vals[n]));
  if (missing.length) return { error: 'Enter values for: ' + missing.map(sym).join(', ') };
  const fn = new Function(...names, 'return ' + expr);
  const ans = fn(...names.map(n => vals[n]));
  if (!isFinite(ans)) return { error: 'The result is not finite (division by zero?). Check your inputs.' };
  const sub = expr.replace(/\b([A-Za-z]+)\b/g, (m, n) => n in vals ? `(${vals[n]})` : m).replace(/\*\*/g, '^').replace(/\*/g, '×');
  return { names, label, unit, expr, sub, ans };
}

const QUIZ = [
  ['The SI unit of stress is…', ['Newton (N)', 'Pascal (Pa)', 'Joule (J)', 'Watt (W)'], 1, 'Stress = force / area = N/m² = Pa.'],
  ['For a series circuit, the same ___ flows through every component.', ['voltage', 'current', 'power', 'resistance'], 1, 'Components in series share one path, so the current is identical.'],
  ['In an ideal Otto cycle, efficiency depends on…', ['peak temperature only', 'compression ratio and γ', 'engine speed', 'fuel type only'], 1, 'η = 1 − r^(1−γ).'],
  ['Binary search on a sorted array of n items has time complexity…', ['O(n)', 'O(n log n)', 'O(log n)', 'O(1)'], 2, 'Each step halves the search space.'],
  ['Poisson’s ratio is the ratio of…', ['stress to strain', 'lateral strain to axial strain', 'shear to normal stress', 'load to area'], 1, 'ν = −(lateral strain) / (axial strain).'],
  ['The time constant of a series RC circuit is…', ['R/C', 'C/R', 'R·C', '1/(R·C)'], 2, 'τ = RC; the capacitor reaches 63.2% after one τ.'],
  ['A 20-tooth gear drives a 40-tooth gear. The output speed is…', ['double the input', 'equal to the input', 'half the input', 'one quarter of the input'], 2, 'ω₂ = ω₁·N₁/N₂ = ω₁/2.'],
  ['Reynolds number is the ratio of…', ['inertial to viscous forces', 'pressure to gravity', 'drag to lift', 'heat to work'], 0, 'Re = ρ·v·D/μ: inertial forces over viscous forces.'],
  ['Which is NOT a typical slicer setting in 3D printing?', ['Layer height', 'Infill density', 'Poisson’s ratio', 'Support density'], 2, 'Poisson’s ratio is a material property, not a slicer setting.'],
  ['Backpropagation is used to compute…', ['the dataset size', 'gradients of the loss w.r.t. weights', 'the number of layers', 'the learning-rate schedule'], 1, 'It applies the chain rule layer by layer to get ∂L/∂w.'],
];

export default function (root) {
  root.innerHTML = `
  <div class="page-head"><span class="tag">EXAM PREPARATION</span><h1 style="font-size:2rem;margin-top:8px">Solve, understand, practise</h1>
  <p>A built-in step-by-step numerical solver, an AI doubt solver (needs a connected model) and a practice quiz.</p></div>
  <div class="tabs"><button class="chip active" data-t="solver">Numerical solver</button><button class="chip" data-t="ask">Ask a doubt</button><button class="chip" data-t="quiz">Practice quiz</button></div>
  <div id="tab"></div>`;
  const tabs = { solver, ask, quiz };
  let off = null;
  function show(t) { $$('.tabs .chip').forEach(c => c.classList.toggle('active', c.dataset.t === t)); off && off(); off = tabs[t]($('#tab')); }
  $('.tabs').onclick = e => { const b = e.target.closest('[data-t]'); if (b) show(b.dataset.t); };
  show('solver');
}

function solver(el) {
  el.innerHTML = `<div class="workspace two"><div class="panel">
    <label class="f">Problem type</label><select id="tpl">${T.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select>
    <label class="f">Solve for</label><select id="tgt"></select>
    <div id="fields"></div>
    <div class="toolbar" style="margin-top:12px"><button class="btn primary" id="go">Solve step by step</button></div>
    <p class="muted" style="font-size:.82rem">Use SI units (m, kg, s, N, Pa, K, V, A…). Scientific notation like 2e11 is fine.</p></div>
  <div class="panel"><h3>Solution</h3><div id="out" class="muted">Choose a problem, fill in the known values and press Solve.</div></div></div>`;
  let tpl = T[0];
  function build() {
    tpl = T.find(t => t.id === $('#tpl').value);
    const prevT = $('#tgt').value;
    $('#tgt').innerHTML = Object.entries(tpl.vars).filter(([, v]) => v[2]).map(([k, v]) => `<option value="${k}">${esc(v[0])} (${sym(k)})</option>`).join('');
    if (prevT in tpl.vars) $('#tgt').value = prevT; fields();
  }
  function fields() {
    const tgt = $('#tgt').value, expr = tpl.vars[tgt][2];
    $('#fields').innerHTML = Object.entries(tpl.vars).filter(([k]) => k !== tgt && new RegExp('\\b' + k + '\\b').test(expr)).map(([k, v]) => `<label class="f">${esc(v[0])} ${sym(k)} [${esc(v[1])}]</label><input type="number" step="any" data-k="${k}">`).join('');
  }
  $('#tpl').onchange = build; $('#tgt').onchange = fields;
  $('#go').onclick = () => {
    const vals = {}; $$('#fields input').forEach(i => { if (i.value !== '') vals[i.dataset.k] = parseFloat(i.value); });
    const r = solve(tpl, $('#tgt').value, vals), o = $('#out');
    if (r.error) { o.innerHTML = `<div class="notice warn">${esc(r.error)}</div>`; return; }
    const tg = $('#tgt').value;
    o.innerHTML = `<div class="sol-step"><b>Given</b><div>${r.names.map(n => `${sym(n)} = ${vals[n]} ${esc(tpl.vars[n][1])}`).join('<br>')}<br>Find: ${sym(tg)} (${esc(r.label)})</div></div>
      <div class="sol-step"><b>Formula</b><div>${esc(tpl.rel)}<br>⇒ ${sym(tg)} = ${esc(r.expr.replace(/\*\*/g, '^').replace(/\*/g, '×'))}</div></div>
      <div class="sol-step"><b>Substitution</b><div>${sym(tg)} = ${esc(r.sub)}</div></div>
      <div class="sol-step"><b>Calculation</b><div>${sym(tg)} = ${esc(String(+r.ans.toPrecision(8)))}</div></div>
      <div class="sol-step"><b>Final answer</b><div style="color:var(--accent);font-size:1.1rem">${sym(tg)} = ${esc(String(+r.ans.toPrecision(5)))} ${esc(r.unit)}</div></div>`;
  };
  build();
  return null;
}

function ask(el) {
  let img = null;
  el.innerHTML = `<div class="workspace two"><div class="panel">
    <label class="f">Question type</label><select id="kind"><option value="num">Numerical problem</option><option value="theory">Theory question</option></select>
    <label class="f">Your question</label><textarea id="q" placeholder="Type or paste your exam question…"></textarea>
    <label class="f">Question image (optional)</label><input type="file" id="img" accept="image/*"><img id="prev" alt="" style="max-width:100%;margin-top:8px;border-radius:8px;display:none">
    <div class="toolbar" style="margin-top:12px"><button class="btn primary" id="go">Solve with VIZ AI</button><button class="btn sm ghost" id="cfg">⚙ Connect AI</button></div>
    <div class="notice">Image questions need a vision-capable model. The image is sent only when you press Solve.</div></div>
  <div class="panel"><h3>Answer</h3><div id="out" class="muted"></div></div></div>`;
  const note = () => { $('#out').innerHTML = aiReady() ? 'Your answer will appear here.' : '<b>AI not connected.</b> Connect a model to use the doubt solver, or use the built-in numerical solver tab for supported formulas.'; };
  $('#img').onchange = e => { const f = e.target.files[0]; if (!f) { img = null; $('#prev').style.display = 'none'; return; } const r = new FileReader(); r.onload = () => { img = r.result; $('#prev').src = img; $('#prev').style.display = 'block'; }; r.readAsDataURL(f); };
  $('#cfg').onclick = () => openAISettings(note);
  $('#go').onclick = async () => {
    const q = $('#q').value.trim(); if (!q && !img) { $('#out').textContent = 'Type a question or attach an image.'; return; }
    if (!aiReady()) { note(); return; }
    $('#out').textContent = 'Solving…'; $('#go').disabled = true;
    const fmtHint = $('#kind').value === 'num' ? 'Use: Given → Formula → Substitution → Calculation → Final Answer (with units). Then add: related formulas, difficulty (easy/medium/hard) and two similar practice questions.' : 'Use: Concept → Explanation → Example → Exam-ready answer. Then add: difficulty and two similar practice questions.';
    const content = img ? [{ type: 'text', text: q || 'Solve the question in the image.' }, { type: 'image_url', image_url: { url: img } }] : q;
    try { $('#out').innerHTML = md(await askAI([{ role: 'system', content: AGENTS.exam.system + ' ' + fmtHint }, { role: 'user', content }])); }
    catch (e) { $('#out').innerHTML = `<div class="notice warn">${esc(e.message)}</div>`; }
    $('#go').disabled = false;
  };
  note(); return null;
}

function quiz(el) {
  let i = 0, score = 0, answered = false;
  const hist = store('quiz', []);
  function draw() {
    if (i >= QUIZ.length) {
      hist.push({ date: new Date().toISOString().slice(0, 10), score, total: QUIZ.length }); save('quiz', hist.slice(-20));
      el.innerHTML = `<div class="panel" style="max-width:560px"><h2>Score: ${score} / ${QUIZ.length}</h2><p class="muted">Saved to your dashboard.</p><button class="btn primary" id="again">Try again</button></div>`;
      $('#again').onclick = () => { i = 0; score = 0; draw(); }; return;
    }
    const [q, opts, ans, why] = QUIZ[i]; answered = false;
    el.innerHTML = `<div class="panel" style="max-width:640px"><div class="muted">Question ${i + 1} of ${QUIZ.length}</div><h3 style="font-size:1.2rem;margin-top:6px">${esc(q)}</h3>${opts.map((o, k) => `<button class="opt" data-k="${k}">${esc(o)}</button>`).join('')}<div id="why" class="muted" style="margin-top:8px"></div><div class="toolbar" style="margin-top:10px"><button class="btn primary" id="nx" hidden>${i === QUIZ.length - 1 ? 'Finish' : 'Next'}</button></div></div>`;
    $$('.opt').forEach(b => b.onclick = () => {
      if (answered) return; answered = true; const k = +b.dataset.k; if (k === ans) score++;
      $$('.opt').forEach(x => { if (+x.dataset.k === ans) x.classList.add('right'); });
      if (k !== ans) b.classList.add('wrong');
      $('#why').textContent = why; $('#nx').hidden = false;
    });
    $('#nx').onclick = () => { i++; draw(); };
  }
  draw(); return null;
}
