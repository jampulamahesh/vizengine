// Graphic Design Studio: a small layered vector-style canvas editor for engineering diagrams.
import { $, $$, esc, store, save, download, uid } from '../util.js';

const W = 960, H = 600;
const SYMBOLS = {
  resistor: (c, x, y, w, h) => { c.moveTo(x, y + h / 2); c.lineTo(x + w * .15, y + h / 2); [.25, .35, .45, .55, .65, .75].forEach((f, i) => c.lineTo(x + w * f, y + (i % 2 ? .8 : .2) * h)); c.lineTo(x + w * .85, y + h / 2); c.lineTo(x + w, y + h / 2); },
  capacitor: (c, x, y, w, h) => { c.moveTo(x, y + h / 2); c.lineTo(x + w * .42, y + h / 2); c.moveTo(x + w * .42, y); c.lineTo(x + w * .42, y + h); c.moveTo(x + w * .58, y); c.lineTo(x + w * .58, y + h); c.moveTo(x + w * .58, y + h / 2); c.lineTo(x + w, y + h / 2); },
  battery: (c, x, y, w, h) => { c.moveTo(x, y + h / 2); c.lineTo(x + w * .35, y + h / 2); c.moveTo(x + w * .35, y + h * .1); c.lineTo(x + w * .35, y + h * .9); c.moveTo(x + w * .5, y + h * .3); c.lineTo(x + w * .5, y + h * .7); c.moveTo(x + w * .65, y + h * .1); c.lineTo(x + w * .65, y + h * .9); c.moveTo(x + w * .65, y + h / 2); c.lineTo(x + w, y + h / 2); },
  ground: (c, x, y, w, h) => { c.moveTo(x + w / 2, y); c.lineTo(x + w / 2, y + h * .5); c.moveTo(x, y + h * .5); c.lineTo(x + w, y + h * .5); c.moveTo(x + w * .2, y + h * .72); c.lineTo(x + w * .8, y + h * .72); c.moveTo(x + w * .4, y + h * .94); c.lineTo(x + w * .6, y + h * .94); },
  arrow: (c, x, y, w, h) => { c.moveTo(x, y + h / 2); c.lineTo(x + w, y + h / 2); c.moveTo(x + w - Math.min(14, w / 3), y + h / 2 - 8); c.lineTo(x + w, y + h / 2); c.lineTo(x + w - Math.min(14, w / 3), y + h / 2 + 8); },
  gear: (c, x, y, w, h) => { const cx = x + w / 2, cy = y + h / 2, R = Math.min(w, h) / 2, n = 10; for (let i = 0; i < n; i++) { const a = i / n * 6.2832, b = (i + .5) / n * 6.2832; [[R * .78, a], [R, a + .05], [R, b - .05], [R * .78, b]].forEach(([r, t], j) => { const px = cx + Math.cos(t) * r, py = cy + Math.sin(t) * r; (i === 0 && j === 0) ? c.moveTo(px, py) : c.lineTo(px, py); }); } c.closePath(); c.moveTo(cx + R * .25, cy); c.arc(cx, cy, R * .25, 0, 6.2832); },
  valve: (c, x, y, w, h) => { c.moveTo(x, y); c.lineTo(x + w, y + h); c.lineTo(x + w, y); c.lineTo(x, y + h); c.closePath(); },
  motor: (c, x, y, w, h) => { c.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, 6.2832); },
};

export default function (root) {
  let objs = store('gfx', []), sel = null, tool = 'select', symbol = 'resistor', drag = null;
  root.innerHTML = `
  <div class="page-head"><span class="tag">GRAPHIC DESIGN STUDIO</span><h1 style="font-size:2rem;margin-top:8px">Draw diagrams, flowcharts and posters</h1>
  <p>Layered canvas with shapes, text and engineering symbols. Your drawing is saved in this browser and can be exported as PNG.</p></div>
  <div class="workspace">
    <div class="panel"><h3>Tools</h3><div class="list" id="tools">${[['select', '⬚ Select / move'], ['rect', '▭ Rectangle'], ['ellipse', '◯ Ellipse'], ['line', '╱ Line / connector'], ['text', 'T Text'], ['symbol', '⚙ Symbol']].map(([k, n]) => `<button data-t="${k}">${n}</button>`).join('')}</div>
      <label class="f">Symbol</label><select id="sym">${Object.keys(SYMBOLS).map(s => `<option>${s}</option>`).join('')}</select>
      <h3 style="margin-top:14px">Templates</h3><div class="list"><button id="tFlow">Flowchart starter</button><button id="tCkt">Simple circuit</button><button id="tClear">Clear canvas</button></div></div>
    <div><div class="canvas-box" style="background:#fff"><canvas id="cv" width="${W}" height="${H}" style="width:100%;height:auto;aspect-ratio:${W}/${H};min-height:0;touch-action:none;cursor:crosshair"></canvas></div>
      <div class="toolbar" style="margin-top:10px"><button class="btn sm" id="png">⬇ PNG</button><button class="btn sm" id="json">⬇ JSON</button><label class="btn sm">⬆ Open JSON<input type="file" id="open" accept=".json" hidden></label><label class="chk"><input type="checkbox" id="grid" checked> Grid snap (10 px)</label><span class="muted" id="hint"></span></div></div>
    <div class="panel"><h3>Properties</h3><div id="props" class="muted">Select an object.</div><h3 style="margin-top:14px">Layers (top first)</h3><div class="list" id="layers"></div></div>
  </div>`;
  const cv = $('#cv'), ctx = cv.getContext('2d');
  const snap = v => $('#grid').checked ? Math.round(v / 10) * 10 : v;
  const persist = () => save('gfx', objs);

  function pathFor(o, c) {
    c.beginPath();
    if (o.type === 'rect') c.rect(o.x, o.y, o.w, o.h);
    else if (o.type === 'ellipse') c.ellipse(o.x + o.w / 2, o.y + o.h / 2, Math.abs(o.w / 2), Math.abs(o.h / 2), 0, 0, 6.2832);
    else if (o.type === 'line') { c.moveTo(o.x, o.y); c.lineTo(o.x + o.w, o.y + o.h); }
    else if (o.type === 'symbol') SYMBOLS[o.symbol](c, Math.min(o.x, o.x + o.w), Math.min(o.y, o.y + o.h), Math.abs(o.w), Math.abs(o.h));
  }
  function bounds(o) {
    if (o.type === 'text') { ctx.font = `${o.size}px Space Grotesk, sans-serif`; return { x: o.x, y: o.y - o.size, w: ctx.measureText(o.text).width, h: o.size * 1.25 }; }
    return { x: Math.min(o.x, o.x + o.w), y: Math.min(o.y, o.y + o.h), w: Math.abs(o.w), h: Math.abs(o.h) };
  }
  function draw(withUI = true) {
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
    if (withUI && $('#grid').checked) { ctx.fillStyle = '#e6ebf2'; for (let x = 0; x < W; x += 20) for (let y = 0; y < H; y += 20) ctx.fillRect(x, y, 1.5, 1.5); }
    objs.forEach(o => {
      if (o.hidden) return;
      ctx.lineWidth = o.sw; ctx.strokeStyle = o.stroke; ctx.fillStyle = o.fill; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      if (o.type === 'text') { ctx.font = `${o.size}px Space Grotesk, sans-serif`; ctx.fillStyle = o.stroke; ctx.fillText(o.text, o.x, o.y); return; }
      pathFor(o, ctx);
      if (o.fill && o.fill !== 'none' && o.type !== 'line' && o.type !== 'symbol') ctx.fill();
      ctx.stroke();
    });
    if (withUI && sel) { const b = bounds(sel); ctx.strokeStyle = '#0a9d86'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]); ctx.strokeRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8); ctx.setLineDash([]); ctx.fillStyle = '#0a9d86'; ctx.fillRect(b.x + b.w + 1, b.y + b.h + 1, 8, 8); }
  }
  const pt = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * W / r.width, (e.clientY - r.top) * H / r.height]; };
  function hit(x, y) {
    for (let i = objs.length - 1; i >= 0; i--) {
      const o = objs[i]; if (o.hidden) continue; const b = bounds(o);
      if (o.type === 'line') { const x2 = o.x + o.w, y2 = o.y + o.h, L = Math.hypot(o.w, o.h) || 1, d = Math.abs((y2 - o.y) * x - (x2 - o.x) * y + x2 * o.y - y2 * o.x) / L; if (d < 8 && x >= b.x - 8 && x <= b.x + b.w + 8 && y >= b.y - 8 && y <= b.y + b.h + 8) return o; }
      else if (x >= b.x - 4 && x <= b.x + b.w + 4 && y >= b.y - 4 && y <= b.y + b.h + 4) return o;
    }
    return null;
  }
  const style = () => ({ fill: tool === 'rect' || tool === 'ellipse' ? '#dff7f1' : 'none', stroke: '#0e1726', sw: 2 });

  cv.addEventListener('pointerdown', e => {
    cv.setPointerCapture(e.pointerId); const [x, y] = pt(e);
    if (tool === 'select') {
      if (sel) { const b = bounds(sel); if (x > b.x + b.w - 2 && x < b.x + b.w + 14 && y > b.y + b.h - 2 && y < b.y + b.h + 14 && sel.type !== 'text') { drag = { mode: 'resize', o: sel }; return; } }
      sel = hit(x, y); drag = sel ? { mode: 'move', dx: x - sel.x, dy: y - sel.y } : null; ui();
    } else if (tool === 'text') {
      const t = prompt('Text:'); if (t) { const o = { id: uid(), type: 'text', x: snap(x), y: snap(y), text: t, size: 22, ...style(), fill: 'none' }; objs.push(o); sel = o; persist(); ui(); }
    } else {
      const o = { id: uid(), type: tool, symbol, x: snap(x), y: snap(y), w: 0, h: 0, ...style() }; objs.push(o); sel = o; drag = { mode: 'create', o };
    }
  });
  cv.addEventListener('pointermove', e => {
    if (!drag) return; const [x, y] = pt(e);
    if (drag.mode === 'move') { sel.x = snap(x - drag.dx); sel.y = snap(y - drag.dy); }
    else { drag.o.w = snap(x) - drag.o.x; drag.o.h = snap(y) - drag.o.y; if (drag.o.type === 'line' && e.shiftKey) { Math.abs(drag.o.w) > Math.abs(drag.o.h) ? drag.o.h = 0 : drag.o.w = 0; } }
  });
  const end = () => {
    if (drag && drag.mode === 'create') { const o = drag.o; if (o.type !== 'text' && Math.abs(o.w) < 4 && Math.abs(o.h) < 4) { o.w = o.type === 'line' ? 100 : 100; o.h = o.type === 'line' ? 0 : (o.type === 'symbol' ? 40 : 60); } tool = 'select'; }
    if (drag) persist(); drag = null; ui();
  };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  const onKey = e => { if ((e.key === 'Delete' || e.key === 'Backspace') && sel && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { objs = objs.filter(o => o !== sel); sel = null; persist(); ui(); } };
  addEventListener('keydown', onKey);

  function ui() {
    $$('#tools button').forEach(b => b.classList.toggle('active', b.dataset.t === tool));
    $('#hint').textContent = { select: 'Click to select, drag to move, bottom-right handle resizes. Delete removes.', text: 'Click the canvas to place text.' }[tool] || 'Drag on the canvas to draw. Hold Shift for straight lines.';
    const p = $('#props');
    if (!sel) p.innerHTML = '<span class="muted">Select an object.</span>';
    else p.innerHTML = `<label class="f">Stroke / text colour</label><input type="color" data-k="stroke" value="${sel.stroke}">${sel.type === 'rect' || sel.type === 'ellipse' ? `<label class="f">Fill</label><input type="color" data-k="fill" value="${sel.fill === 'none' ? '#ffffff' : sel.fill}">` : ''}${sel.type === 'text' ? `<label class="f">Text</label><input type="text" data-k="text" value="${esc(sel.text)}"><label class="f">Size</label><input type="number" data-k="size" value="${sel.size}" min="8" max="120">` : `<label class="f">Line width</label><input type="number" data-k="sw" value="${sel.sw}" min="1" max="20">`}`;
    $$('#props [data-k]').forEach(i => i.oninput = () => { const k = i.dataset.k; sel[k] = i.type === 'number' ? +i.value : i.value; persist(); });
    $('#layers').innerHTML = [...objs].reverse().map(o => `<button data-id="${o.id}" class="${o === sel ? 'active' : ''}"><span>${o.hidden ? '○' : '◉'} ${esc(o.type === 'text' ? '“' + o.text.slice(0, 14) + '”' : o.type === 'symbol' ? o.symbol : o.type)}</span><small><span data-a="up">▲</span> <span data-a="dn">▼</span> <span data-a="eye">👁</span> <span data-a="del">✕</span></small></button>`).join('') || '<span class="muted">Empty canvas.</span>';
  }
  $('#layers').onclick = e => {
    const b = e.target.closest('button'); if (!b) return; const i = objs.findIndex(o => o.id === b.dataset.id), a = e.target.dataset.a, o = objs[i];
    if (a === 'up' && i < objs.length - 1) [objs[i], objs[i + 1]] = [objs[i + 1], objs[i]];
    else if (a === 'dn' && i > 0) [objs[i], objs[i - 1]] = [objs[i - 1], objs[i]];
    else if (a === 'eye') o.hidden = !o.hidden;
    else if (a === 'del') { objs.splice(i, 1); if (sel === o) sel = null; }
    else sel = o;
    persist(); ui();
  };
  $('#tools').onclick = e => { const b = e.target.closest('button'); if (b) { tool = b.dataset.t; sel = null; ui(); } };
  $('#sym').onchange = e => { symbol = e.target.value; tool = 'symbol'; ui(); };
  $('#png').onclick = () => { draw(false); cv.toBlob(b => { download('diagram.png', b); draw(); }); };
  $('#json').onclick = () => download('diagram.json', JSON.stringify(objs, null, 1), 'application/json');
  $('#open').onchange = async e => { try { const a = JSON.parse(await e.target.files[0].text()); if (Array.isArray(a)) { objs = a; sel = null; persist(); ui(); } } catch { alert('That file is not a valid diagram JSON.'); } };
  const S = { stroke: '#0e1726', sw: 2 };
  const R = (x, y, w, h, t, fill = '#dff7f1') => { objs.push({ id: uid(), type: 'rect', x, y, w, h, fill, ...S }); objs.push({ id: uid(), type: 'text', x: x + 12, y: y + h / 2 + 6, text: t, size: 18, fill: 'none', ...S }); };
  const L = (x, y, w, h) => objs.push({ id: uid(), type: 'line', x, y, w, h, fill: 'none', ...S });
  $('#tFlow').onclick = () => { objs = []; R(380, 30, 180, 56, 'Start', '#cdeafe'); L(470, 86, 0, 34); R(380, 120, 180, 56, 'Read sensor'); L(470, 176, 0, 34); R(380, 210, 180, 56, 'Process data'); L(470, 266, 0, 34); R(380, 300, 180, 56, 'Decision?', '#ffe9c2'); L(470, 356, 0, 34); R(380, 390, 180, 56, 'Actuate output'); L(470, 446, 0, 34); R(380, 480, 180, 56, 'End', '#cdeafe'); sel = null; persist(); ui(); };
  $('#tCkt').onclick = () => { objs = []; L(200, 200, 560, 0); L(200, 400, 560, 0); L(200, 200, 0, 200); L(760, 200, 0, 200); objs.push({ id: uid(), type: 'symbol', symbol: 'battery', x: 160, y: 270, w: 80, h: 60, fill: 'none', ...S }, { id: uid(), type: 'symbol', symbol: 'resistor', x: 420, y: 180, w: 120, h: 40, fill: 'none', ...S }, { id: uid(), type: 'symbol', symbol: 'capacitor', x: 720, y: 270, w: 80, h: 60, fill: 'none', ...S }, { id: uid(), type: 'text', x: 450, y: 170, text: 'R1', size: 20, fill: 'none', ...S }); sel = null; persist(); ui(); };
  $('#tClear').onclick = () => { if (!objs.length || confirm('Clear the whole canvas?')) { objs = []; sel = null; persist(); ui(); } };

  let raf; const tick = () => { draw(); raf = requestAnimationFrame(tick); }; tick();
  ui();
  return () => { cancelAnimationFrame(raf); removeEventListener('keydown', onKey); };
}
