import { BRANCHES, LABS } from '../data.js';
import { $, esc, fitCanvas, loop, drawGear, colors } from '../util.js';

export default function (root) {
  root.innerHTML = `
  <section class="hero">
    <div>
      <div class="flow">LEARN → VISUALIZE → SIMULATE → CREATE → BUILD</div>
      <h1>Engineering <em>Comes Alive.</em></h1>
      <p class="lead">Learn engineering through AI, interactive visualisation, 3D models, simulations, animation and real-world projects.</p>
      <div class="cta"><a class="btn primary" href="#/courses">Start Learning</a><a class="btn" href="#/project-studio">Create a Project</a><a class="btn ghost" href="#/ai-tutor">Ask AI</a></div>
    </div>
    <canvas id="hero" aria-hidden="true"></canvas>
  </section>
  <section class="block"><h2>Your engineering laboratory</h2><p class="muted">Every concept goes from page to picture to working model.</p>
    <div class="grid auto">${LABS.map(([h, n, d, i]) => `<a class="card lab-card" href="${h}"><div class="ico">${i}</div><h3>${esc(n)}</h3><p>${esc(d)}</p></a>`).join('')}</div></section>
  <section class="block"><div class="toolbar" style="justify-content:space-between"><div><h2>${BRANCHES.length} engineering branches</h2><p class="muted">From CSE to Biomedical: one visual way to learn.</p></div><a class="btn" href="#/courses">All courses</a></div>
    <div class="grid auto-s">${BRANCHES.map(b => `<a class="card branch-card" href="#/courses?branch=${b.id}"><b>${b.short}</b><span>${esc(b.name)}</span></a>`).join('')}</div></section>
  <section class="block"><h2>How it works</h2><div class="steps"><span>Learn</span><i>→</i><span>Visualize</span><i>→</i><span>Simulate</span><i>→</i><span>Create</span><i>→</i><span>Build</span></div>
    <p class="muted" style="margin-top:14px;max-width:70ch">A student doesn't just read how an engine works. They see it, rotate it, take it apart, animate its cycle, ask AI about it, create a project around it and prepare a model for 3D printing.</p></section>
  <section class="block"><div class="notice"><b>What's real today:</b> the labs, simulations, solver, quiz, project scaffolds, diagram editor and STL inspector all run in your browser. AI features need you to connect your own model, and accounts/community need a backend (not included yet). Nothing here is faked.</div></section>`;

  const st = fitCanvas($('#hero'));
  const stop = loop((dt, t) => {
    const { ctx, w, h } = st; ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = colors.line; ctx.lineWidth = 1; ctx.globalAlpha = .6;
    for (let x = 0; x < w; x += 28) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
    for (let y = 0; y < h; y += 28) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
    ctx.globalAlpha = 1;
    const u = Math.min(w, h) / 10, m = u * .085;
    const r1 = 16 * m, r2 = 10 * m, r3 = 22 * m;
    const x1 = w * .4, y1 = h * .34, x2 = x1 + r1 + r2, y2 = y1, x3 = x1, y3 = y1 + r1 + r3;
    const a = t * .5;
    drawGear(ctx, x1, y1, r1 + m, 16, a, colors.accent, colors.text, 2.2 * m);
    drawGear(ctx, x2, y2, r2 + m, 10, Math.PI - 1.1 * (Math.PI * 2 / 10) - a * 1.6, colors.accent2, colors.text, 2.2 * m);
    drawGear(ctx, x3, y3, r3 + m, 22, -a * 16 / 22 + .5, '#4aa3ff', colors.text, 2.2 * m);
    ctx.fillStyle = colors.mute; ctx.font = '12px JetBrains Mono, monospace';
    ctx.fillText('N=16  N=10  N=22', 16, h - 16);
  });
  return () => { stop(); st.destroy(); };
}
