import { $, $$, esc, fmt, sliderRow, bindSliders } from '../util.js';

export default async function (root, q) {
  const [{ createViewer, THREE }, { MODELS }] = await Promise.all([import('../viewer.js'), import('../models.js')]);

  root.innerHTML = `
  <div class="page-head"><span class="tag">3D LAB</span><h1 style="font-size:2rem;margin-top:8px">Interactive 3D workspace</h1>
  <p>Rotate (drag), pan (right-drag), zoom (scroll). Explode, section, isolate parts, label them and measure. 1 scene unit = 10 mm.</p></div>
  <div class="workspace">
    <div>
      <div class="panel"><h3>Models</h3><div class="list" id="mlist">${MODELS.map(m => `<button data-id="${m.id}"><span>${esc(m.name)}</span></button>`).join('')}</div></div>
      <div class="panel" style="margin-top:14px"><h3>Parts</h3><div class="list" id="plist"></div></div>
    </div>
    <div>
      <div class="viewport" id="vp"><div class="overlay" id="labels"></div><div class="hud" id="hud"></div></div>
      <div class="toolbar" style="margin-top:10px">
        <button class="btn sm" id="reset">Reset view</button>
        <label class="chk"><input type="checkbox" id="animate" checked> Animate</label>
        <label class="chk"><input type="checkbox" id="spin"> Auto-rotate</label>
        <label class="chk"><input type="checkbox" id="wire"> Wireframe</label>
        <label class="chk"><input type="checkbox" id="lbls"> Labels</label>
        <label class="chk"><input type="checkbox" id="meas"> Measure (click 2 points)</label>
      </div>
    </div>
    <div class="panel">
      <h3>View</h3>
      <label class="row"><span>Explode</span><output>0</output><input type="range" data-p="explode" min="0" max="1" step="0.01" value="0"></label>
      <label class="row"><span>Assembly step</span><output id="stepOut">–</output><input type="range" id="step" min="0" max="1" step="1" value="1"></label>
      <label class="f">Section plane</label>
      <div class="toolbar"><select id="axis" style="width:auto"><option value="y">Horizontal (Y)</option><option value="x">Vertical (X)</option><option value="z">Vertical (Z)</option></select></div>
      <label class="row"><span>Cut position</span><output>off</output><input type="range" id="cut" min="0" max="100" step="1" value="100"></label>
      <div id="mparams"></div>
      <h3 style="margin-top:14px">Measurements</h3><dl class="kv" id="dims"></dl><p class="muted" id="mres" style="margin:6px 0 0"></p>
      <h3 style="margin-top:14px">Selected part</h3><div id="sel" class="muted">Click a part in the view or list.</div>
      <div id="extra"></div>
    </div>
  </div>`;

  const V = createViewer($('#vp'));
  const { scene, camera, renderer } = V;
  const st = { explode: 0, angle: 0, animate: true, step: 99, axis: 'y', cut: 100 };
  const plane = new THREE.Plane(new THREE.Vector3(0, -1, 0), 100);
  let model = null, sel = null, isolate = -1, hidden = new Set(), pts = [], mgroup = new THREE.Group();
  scene.add(mgroup);

  const bbox = () => new THREE.Box3().setFromObject(model.group);

  function load(id) {
    if (model) { scene.remove(model.group); model.group.traverse(o => { o.geometry && o.geometry.dispose(); }); }
    const def = MODELS.find(m => m.id === id) || MODELS[0];
    model = def.build(); scene.add(model.group);
    sel = null; isolate = -1; hidden = new Set(); clearMeasure();
    st.explode = 0; st.step = model.parts.length;
    $('[data-p=explode]').value = 0; $('[data-p=explode]').parentElement.querySelector('output').textContent = '0';
    const sl = $('#step'); sl.max = model.parts.length; sl.value = model.parts.length;
    model.params.forEach(p => st[p.id] = p.val);
    $('#mparams').innerHTML = model.params.length ? '<h3 style="margin-top:14px">Model controls</h3>' + model.params.map(sliderRow).join('') : '';
    bindSliders($('#mparams'), st);
    $$('#mlist button').forEach(b => b.classList.toggle('active', b.dataset.id === def.id));
    $('#plist').innerHTML = model.parts.map((p, i) => `<button data-i="${i}"><span>${esc(p.name)}</span><small data-eye="${i}">◉</small></button>`).join('');
    // labels
    $('#labels').innerHTML = model.parts.map((p, i) => `<div class="lbl" data-l="${i}" style="display:none">${esc(p.name)}</div>`).join('');
    $('#extra').innerHTML = `<p class="muted" style="margin-top:12px">${esc(def.blurb)}</p>` + (def.id === 'robot' ? '<h3>Forward kinematics</h3><dl class="kv" id="fk"></dl>' : '');
    V.resetView(model.focus, [model.focus[0] + 4.5, model.focus[1] + 2, model.focus[2] + 6]);
    history.replaceState(null, '', '#/3d-lab?m=' + def.id);
    applyMaterials(); applyVisibility();
  }

  function mats() { const a = []; model.parts.forEach(p => p.meshes.forEach(m => a.push(m.material))); return a; }
  function applyMaterials() {
    const active = st.cut < 100;
    const b = bbox(); // bbox while assembled isn't guaranteed; use current
    const ax = st.axis, min = b.min[ax], max = b.max[ax];
    const n = new THREE.Vector3(ax === 'x' ? -1 : 0, ax === 'y' ? -1 : 0, ax === 'z' ? -1 : 0);
    plane.normal.copy(n); plane.constant = min + (max - min) * st.cut / 100 + 1e-3;
    mats().forEach(m => {
      m.clippingPlanes = active ? [plane] : null;
      if (active) m.side = THREE.DoubleSide;
      if (m.wireframe !== undefined) m.wireframe = $('#wire').checked;
    });
  }
  function applyVisibility() {
    model.parts.forEach((p, i) => {
      const vis = isolate >= 0 ? i === isolate : (i < st.step && !hidden.has(i));
      p.meshes.forEach(m => { m.visible = vis; if (m.material.emissive) m.material.emissive.setHex(p === sel ? 0x0e5a50 : 0x000000); });
    });
    $$('#plist button').forEach((b, i) => { b.classList.toggle('active', model.parts[i] === sel); const eye = b.querySelector('[data-eye]'); eye.textContent = (isolate >= 0 ? i === isolate : !hidden.has(i)) ? '◉' : '○'; });
    $('#stepOut').textContent = st.step + ' / ' + model.parts.length;
  }
  function select(p) {
    sel = p;
    $('#sel').innerHTML = p ? `<b>${esc(p.name)}</b><dl class="kv" style="margin-top:6px"><dt>Material</dt><dd>${esc(p.material)}</dd></dl><p class="muted" style="margin:6px 0 0">${esc(p.note)}</p><div class="toolbar" style="margin-top:8px"><button class="btn sm" id="iso">${isolate >= 0 ? 'Show all' : 'Isolate'}</button></div>` : 'Click a part in the view or list.';
    applyVisibility();
  }

  // events
  $('#mlist').onclick = e => { const b = e.target.closest('button'); if (b) load(b.dataset.id); };
  $('#plist').onclick = e => {
    const b = e.target.closest('button'); if (!b) return; const i = +b.dataset.i;
    if (e.target.dataset.eye !== undefined) { hidden.has(i) ? hidden.delete(i) : hidden.add(i); applyVisibility(); }
    else select(model.parts[i]);
  };
  $('#sel').onclick = e => { if (e.target.id === 'iso') { isolate = isolate >= 0 ? -1 : model.parts.indexOf(sel); select(sel); } };
  $('#reset').onclick = () => V.resetView(model.focus, [model.focus[0] + 4.5, model.focus[1] + 2, model.focus[2] + 6]);
  $('#animate').onchange = e => st.animate = e.target.checked;
  $('#spin').onchange = e => V.controls.autoRotate = e.target.checked;
  $('#wire').onchange = applyMaterials;
  $('#lbls').onchange = e => { $$('#labels .lbl').forEach(l => l.style.display = e.target.checked ? '' : 'none'); };
  $('#meas').onchange = () => clearMeasure();
  $('#axis').onchange = e => { st.axis = e.target.value; applyMaterials(); };
  $('#cut').oninput = e => { st.cut = +e.target.value; e.target.parentElement.querySelector('output').textContent = st.cut >= 100 ? 'off' : st.cut + '%'; applyMaterials(); };
  $('#step').oninput = e => { st.step = +e.target.value; applyVisibility(); };
  bindSliders($('.panel [data-p=explode]').closest('.panel'), st);

  // picking & measuring
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  let down = null;
  renderer.domElement.addEventListener('pointerdown', e => { down = [e.clientX, e.clientY]; });
  renderer.domElement.addEventListener('pointerup', e => {
    if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 5) return;
    const r = renderer.domElement.getBoundingClientRect();
    ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    const targets = []; model.parts.forEach(p => p.meshes.forEach(m => m.visible && targets.push(m)));
    const hit = ray.intersectObjects(targets, false).find(h => !h.object.material.clippingPlanes || h.object.material.clippingPlanes.length === 0 || plane.distanceToPoint(h.point) <= 0);
    if (!hit) { if ($('#meas').checked) return; select(null); return; }
    if ($('#meas').checked) addPoint(hit.point); else select(hit.object.userData.part);
  });
  function clearMeasure() { pts = []; while (mgroup.children.length) mgroup.remove(mgroup.children[0]); $('#mres').textContent = $('#meas').checked ? 'Click two points on the model.' : ''; }
  function addPoint(p) {
    if (pts.length >= 2) clearMeasure();
    pts.push(p.clone());
    const s = new THREE.Mesh(new THREE.SphereGeometry(.05, 12, 8), new THREE.MeshBasicMaterial({ color: 0xff6b4a, depthTest: false })); s.position.copy(p); s.renderOrder = 10; mgroup.add(s);
    if (pts.length === 2) {
      const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0xff6b4a, depthTest: false })); l.renderOrder = 10; mgroup.add(l);
      $('#mres').innerHTML = `Distance: <b style="color:var(--accent)">${fmt(pts[0].distanceTo(pts[1]) * 10, 2)} mm</b>`;
    } else $('#mres').textContent = 'Click a second point.';
  }

  // frame loop
  let n = 0; const tmp = new THREE.Box3(), c = new THREE.Vector3();
  V.onFrame(dt => {
    if (!model) return;
    if (st.animate) st.angle = (st.angle + 60 * dt) % 720;
    model.update(st);
    model.parts.forEach(p => { p.obj.position.copy(p.home).addScaledVector(p.dir, st.explode); });
    if ($('#lbls').checked) model.parts.forEach((p, i) => {
      tmp.makeEmpty(); p.meshes.forEach(m => tmp.expandByObject(m)); tmp.getCenter(c);
      const el = $(`#labels [data-l="${i}"]`); if (!el) return;
      const pr = V.project(c); el.style.left = pr.x + 'px'; el.style.top = pr.y + 'px'; el.style.opacity = p.meshes[0].visible && pr.ok ? 1 : 0;
    });
    if (n++ % 15 === 0) {
      const b = bbox(), s = b.getSize(new THREE.Vector3());
      $('#dims').innerHTML = `<dt>Width (X)</dt><dd>${fmt(s.x * 10, 1)} mm</dd><dt>Height (Y)</dt><dd>${fmt(s.y * 10, 1)} mm</dd><dt>Depth (Z)</dt><dd>${fmt(s.z * 10, 1)} mm</dd>`;
      $('#hud').textContent = model.parts.length + ' parts';
      if (model.tipPosition) { const t = model.tipPosition(); const fk = $('#fk'); if (fk) fk.innerHTML = `<dt>Tip X</dt><dd>${fmt(t.x * 10, 1)} mm</dd><dt>Tip Y</dt><dd>${fmt(t.y * 10, 1)} mm</dd><dt>Tip Z</dt><dd>${fmt(t.z * 10, 1)} mm</dd>`; }
      if (st.cut < 100) applyMaterials();
    }
  });

  load(q.get('m') || 'engine');
  return () => V.dispose();
}
