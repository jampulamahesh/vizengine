import { $, $$, esc, fmt, loop } from '../util.js';
import { STROKES, strokeAt } from '../concepts.js';

// keyframes for the robot pick-and-place routine: [time s, j1, j2, j3, label]
const ROBOT_KF = [[0, 0, 0, 0, 'Home'], [2, 60, 35, -50, 'Reach'], [3.5, 60, 55, -75, 'Grip'], [5, 60, 10, -20, 'Lift'], [7.5, -70, 10, -20, 'Place'], [9, -70, 40, -60, 'Release'], [11, 0, 0, 0, 'Return']];
const ease = u => u * u * (3 - 2 * u);
function robotAt(t) {
  let i = ROBOT_KF.findIndex(k => k[0] > t); if (i < 0) i = ROBOT_KF.length - 1; if (i === 0) i = 1;
  const a = ROBOT_KF[i - 1], b = ROBOT_KF[i], u = ease(Math.min(1, Math.max(0, (t - a[0]) / (b[0] - a[0]))));
  return { j1: a[1] + (b[1] - a[1]) * u, j2: a[2] + (b[2] - a[2]) * u, j3: a[3] + (b[3] - a[3]) * u };
}

const SCEN = {
  cycle: { name: 'Engine cycle', model: 'engine', max: 720, unit: '°', step: 15, markers: STROKES.map(s => [s[1], s[0]]).concat([[720, 'End']]), loop: true },
  assembly: { name: 'Engine assembly', model: 'engine', max: 100, unit: '%', step: 2, markers: null, loop: false },
  robot: { name: 'Robot pick & place', model: 'robot', max: 11, unit: ' s', step: .25, markers: ROBOT_KF.map(k => [k[0], k[4]]), loop: true },
};

export default async function (root, q) {
  const [{ createViewer, THREE }, { MODELS, applyAssembly }] = await Promise.all([import('../viewer.js'), import('../models.js')]);
  let key = SCEN[q.get('s')] ? q.get('s') : 'cycle';

  root.innerHTML = `
  <div class="page-head"><span class="tag">4D VISUALIZATION</span><h1 style="font-size:2rem;margin-top:8px">3D space + time</h1>
  <p>Scrub the timeline to watch a model change over time: a working cycle, an assembly sequence or a robot routine.</p>
  <div class="notice warn"><b>Educational visualisation.</b> Motion is idealised kinematics driven by the timeline. It is not a scientific-grade simulation: there is no CFD, combustion chemistry or dynamic loading.</div></div>
  <div class="toolbar" id="scen" style="margin-bottom:12px">${Object.entries(SCEN).map(([k, s]) => `<button class="chip" data-k="${k}">${s.name}</button>`).join('')}</div>
  <div class="workspace two">
    <div>
      <div class="viewport" id="vp"><div class="hud" id="hud"></div></div>
      <div class="panel" style="margin-top:12px">
        <div class="toolbar" style="margin-bottom:10px">
          <button class="btn sm" id="prev" title="Previous marker">⏮</button>
          <button class="btn sm" id="back" title="Step back">◀ Step</button>
          <button class="btn sm primary" id="play">⏸ Pause</button>
          <button class="btn sm" id="fwd" title="Step forward">Step ▶</button>
          <button class="btn sm" id="next" title="Next marker">⏭</button>
          <select id="speed" style="width:auto"><option value=".25">0.25×</option><option value=".5">0.5×</option><option value="1" selected>1×</option><option value="2">2×</option><option value="4">4×</option></select>
          <label class="chk toolbar"><input type="checkbox" id="loop" checked> Loop</label>
          <span class="muted" id="tdisp" style="margin-left:auto;font-family:var(--mono)"></span>
        </div>
        <div class="timeline"><input type="range" id="tl" min="0" max="1" step="0.1" value="0"><div class="ticks" id="ticks"></div></div>
      </div>
    </div>
    <div class="panel"><h3>Phase</h3><div id="phase"></div><h3 style="margin-top:16px">About this scenario</h3><div id="about" class="muted"></div></div>
  </div>`;

  const V = createViewer($('#vp'));
  let model, time = 0, playing = true, speed = 1, S = SCEN[key];
  const st = { angle: 0, j1: 0, j2: 0, j3: 0 };

  function setScenario(k) {
    key = k; S = SCEN[k];
    if (model) { V.scene.remove(model.group); model.group.traverse(o => o.geometry && o.geometry.dispose()); }
    model = MODELS.find(m => m.id === S.model).build(); V.scene.add(model.group);
    V.resetView(model.focus, [model.focus[0] + 4.5, model.focus[1] + 2, model.focus[2] + 6]);
    time = 0; $('#tl').max = S.max; $('#tl').step = S.step; $('#tl').value = 0; $('#loop').checked = S.loop;
    const marks = S.markers || model.parts.map((p, i) => [S.max * (i + 1) / model.parts.length, p.name]);
    S.m = marks;
    $('#ticks').innerHTML = marks.map(([t, n]) => `<button class="tick" data-t="${t}" style="left:${t / S.max * 100}%">${esc(n)}</button>`).join('');
    $$('#scen .chip').forEach(c => c.classList.toggle('active', c.dataset.k === k));
    $('#about').textContent = { cycle: 'One full four-stroke cycle = 720° of crank rotation. Valve lift and the combustion flash are tied to the crank angle.', assembly: 'Parts fly in one by one in a typical build order. Use Step to inspect each stage.', robot: 'Joint angles are interpolated between keyframes (Home → Reach → Grip → Lift → Place → Release → Return) with smooth easing.' }[k];
    history.replaceState(null, '', '#/4d?s=' + k);
  }

  function apply() {
    if (key === 'cycle') { st.angle = time; model.update(st); model.parts.forEach(p => { p.obj.position.copy(p.home); p.meshes.forEach(m => m.visible = true); }); }
    else if (key === 'assembly') { st.angle = 0; model.update(st); applyAssembly(model, time / S.max); }
    else { Object.assign(st, robotAt(time)); model.update(st); model.parts.forEach(p => { p.obj.position.copy(p.home); p.meshes.forEach(m => m.visible = true); }); }
    $('#tl').value = time;
    $('#tdisp').textContent = `${fmt(time, 1)}${S.unit} / ${S.max}${S.unit}`;
    let html;
    if (key === 'cycle') { const s = strokeAt(time % 720); html = `<p><b style="color:${s[3]}">${s[0]} stroke</b></p><p class="muted">${s[4]}</p>`; }
    else if (key === 'assembly') { const N = model.parts.length, i = Math.min(N - 1, Math.floor(time / S.max * N)); html = `<p><b>Step ${Math.min(N, i + 1)} of ${N}</b></p><p class="muted">${esc(model.parts[i].name)} — ${esc(model.parts[i].note)}</p>`; }
    else { const t = model.tipPosition(); const near = S.m.reduce((a, b) => Math.abs(b[0] - time) < Math.abs(a[0] - time) ? b : a); html = `<p><b>${esc(near[1])}</b></p><dl class="kv"><dt>Joint 1</dt><dd>${fmt(st.j1, 1)}°</dd><dt>Joint 2</dt><dd>${fmt(st.j2, 1)}°</dd><dt>Joint 3</dt><dd>${fmt(st.j3, 1)}°</dd><dt>Tip</dt><dd>${fmt(t.x * 10, 0)}, ${fmt(t.y * 10, 0)}, ${fmt(t.z * 10, 0)} mm</dd></dl>`; }
    if ($('#phase').dataset.h !== html) { $('#phase').innerHTML = html; $('#phase').dataset.h = html; }
  }

  const setPlay = p => { playing = p; $('#play').textContent = p ? '⏸ Pause' : '▶ Play'; };
  const baseRate = () => ({ cycle: 120, assembly: 12, robot: 1 }[key]);
  V.onFrame(dt => {
    if (playing) { time += baseRate() * speed * dt; if (time >= S.max) { if ($('#loop').checked) time = 0; else { time = S.max; setPlay(false); } } }
    apply();
  });

  $('#scen').onclick = e => { const b = e.target.closest('[data-k]'); if (b) setScenario(b.dataset.k); };
  $('#play').onclick = () => { if (!playing && time >= S.max) time = 0; setPlay(!playing); };
  $('#tl').oninput = e => { time = +e.target.value; setPlay(false); };
  $('#speed').onchange = e => speed = +e.target.value;
  $('#fwd').onclick = () => { setPlay(false); time = Math.min(S.max, time + S.step); };
  $('#back').onclick = () => { setPlay(false); time = Math.max(0, time - S.step); };
  const marks = () => S.m.map(m => m[0]);
  $('#next').onclick = () => { setPlay(false); const n = marks().find(t => t > time + 1e-6); time = n ?? S.max; };
  $('#prev').onclick = () => { setPlay(false); const p = marks().filter(t => t < time - 1e-6).pop(); time = p ?? 0; };
  $('#ticks').onclick = e => { const b = e.target.closest('[data-t]'); if (b) { time = +b.dataset.t; setPlay(false); } };

  setScenario(key);
  return () => V.dispose();
}
