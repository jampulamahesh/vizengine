import { $, $$, esc, fmt } from '../util.js';
import { parseSTL, parseOBJ, rotate90, scaled, analyze, estimate, fmtTime, suggestOrientations, MATERIALS } from '../stl.js';

const EDU = {
  'Layer height': 'The thickness of each printed layer (typically 0.1–0.3 mm). Thin layers give smooth surfaces but take much longer; thick layers print fast but show steps. Rule of thumb: ≤ 75% of the nozzle diameter.',
  'Infill': 'The internal fill pattern density. 10–20% is enough for display parts; 40–100% for load-bearing parts. Strength grows slowly with infill, while print time and material grow quickly.',
  'Walls (perimeters)': 'Outer shells printed around each layer. Walls contribute more strength than infill. 2–3 walls is typical; thin walls need at least 2 for stiffness.',
  'Supports': 'Temporary structures under overhangs steeper than about 45° from vertical. They cost material and leave surface marks, so choose an orientation that needs few supports.',
  'Orientation': 'FDM parts are weakest between layers. Orient the part so the main loads act along the layers, put the flattest large face on the bed and minimise overhangs.',
  'STL vs OBJ': 'STL stores only triangles (no colours or units, usually mm). OBJ also stores shared vertices and can carry materials. Both are "meshes": they must be watertight (closed) to slice correctly.',
  'Slicing': 'A slicer cuts the model into horizontal layers and generates G-code: the machine instructions for nozzle path, extrusion, temperature and speed. This website only helps you inspect and learn; it does not control any printer.',
};

export default async function (root) {
  const [{ createViewer, THREE }, { gearGeometry }] = await Promise.all([import('../viewer.js'), import('../models.js')]);
  let base = null, pos = null, name = '', unit = 1;
  const S = { layer: .2, infill: 20, walls: 2, speed: 50, supports: false, material: 'PLA' };

  root.innerHTML = `
  <div class="page-head"><span class="tag">3D PRINTING LAB</span><h1 style="font-size:2rem;margin-top:8px">Inspect a model and learn to slice</h1>
  <p>Load an STL or OBJ file (it stays in your browser), check its size and printability, and see how slicer settings change time and material.</p>
  <div class="notice warn"><b>Estimates only.</b> Real slicers compute exact toolpaths. This page does not connect to or control any 3D printer.</div></div>
  <div class="workspace">
    <div class="panel"><h3>Model</h3>
      <label class="btn" style="width:100%;justify-content:center">⬆ Open STL / OBJ<input type="file" id="file" accept=".stl,.obj" hidden></label>
      <div class="toolbar" style="margin-top:8px"><button class="btn sm" id="sample">Load sample gear</button></div>
      <label class="f">Model units</label><select id="unit"><option value="1">millimetres</option><option value="10">centimetres</option><option value="25.4">inches</option></select>
      <h3 style="margin-top:14px">Orientation</h3>
      <div class="toolbar"><button class="btn sm" data-r="x">Rot X 90°</button><button class="btn sm" data-r="y">Rot Y 90°</button><button class="btn sm" data-r="z">Rot Z 90°</button></div>
      <button class="btn sm" id="suggest" style="margin-top:8px">Suggest best orientation</button><div id="sugg" style="margin-top:8px"></div></div>
    <div><div class="viewport" id="vp"><div class="hud" id="hud">Load a model to begin.</div></div>
      <div class="panel" style="margin-top:12px"><h3>Slicer settings (estimate)</h3>
        <div class="grid c3"><label class="f">Layer height: <b id="lh">0.2</b> mm<input type="range" id="layer" min=".05" max=".4" step=".05" value=".2"></label>
        <label class="f">Infill: <b id="inf">20</b> %<input type="range" id="infill" min="0" max="100" step="5" value="20"></label>
        <label class="f">Walls: <b id="wl">2</b><input type="range" id="walls" min="1" max="6" step="1" value="2"></label>
        <label class="f">Print speed: <b id="sp">50</b> mm/s<input type="range" id="speed" min="20" max="150" step="5" value="50"></label>
        <label class="f">Material<select id="mat">${Object.keys(MATERIALS).map(m => `<option>${m}</option>`).join('')}</select></label>
        <label class="f"><span class="toolbar"><input type="checkbox" id="sup"> Supports enabled</span></label></div></div></div>
    <div class="panel"><h3>Analysis</h3><div id="stats" class="muted">No model loaded.</div></div>
  </div>
  <section class="block"><h2>Learn: what each setting means</h2><div class="grid auto">${Object.entries(EDU).map(([k, v]) => `<div class="card"><h3>${k}</h3><p>${v}</p></div>`).join('')}</div></section>`;

  const V = createViewer($('#vp'));
  V.grid.visible = false; V.scene.remove(V.grid);
  const bedGrid = new THREE.GridHelper(10, 22, 0x35e0c2, 0x24344d); V.scene.add(bedGrid);
  let mesh = null, overMesh = null;

  function setModel(p, nm) { base = p; name = nm; refresh(true); }
  function current() { return scaled(pos0(), unit); }
  let rot = null; // working copy (orientation applied)
  const pos0 = () => rot || base;
  function refresh(fit) {
    if (!base) return;
    pos = current();
    const a = analyze(pos);
    // build geometry: centre in XY, sit on bed (Z up -> Three Y up via rotation)
    if (mesh) { V.scene.remove(mesh); mesh.geometry.dispose(); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos.slice(), 3));
    g.translate(-(a.min[0] + a.max[0]) / 2, -(a.min[1] + a.max[1]) / 2, -a.min[2]); g.computeVertexNormals();
    const k = 5 / Math.max(...a.size, 1e-6);
    mesh = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: 0x35e0c2, metalness: .2, roughness: .55, side: THREE.DoubleSide }));
    mesh.rotation.x = -Math.PI / 2; mesh.scale.setScalar(k); V.scene.add(mesh);
    bedGrid.scale.setScalar(1);
    if (fit) { V.resetView([0, a.size[2] * k / 2, 0], [6, 5, 8]); }
    $('#hud').textContent = `${name} · ${a.triangles.toLocaleString()} triangles`;
    stats(a);
  }
  function stats(a) {
    const e = estimate(a, S);
    const bed = 220, fitsBed = a.size[0] <= bed && a.size[1] <= bed && a.size[2] <= 250;
    const needSup = a.overhangArea / a.area > .02;
    $('#stats').innerHTML = `<dl class="kv"><dt>Size X×Y×Z</dt><dd>${fmt(a.size[0], 1)} × ${fmt(a.size[1], 1)} × ${fmt(a.size[2], 1)} mm</dd><dt>Volume</dt><dd>${fmt(a.volume / 1000, 2)} cm³</dd><dt>Surface area</dt><dd>${fmt(a.area / 100, 1)} cm²</dd><dt>Triangles</dt><dd>${a.triangles.toLocaleString()}</dd></dl>
      <h3 style="margin-top:12px">Printability</h3><ul style="margin:.2em 0 0 1.1em;padding:0;font-size:.88rem">
      <li>${fitsBed ? '✔' : '⚠'} ${fitsBed ? 'Fits a 220×220×250 mm printer bed' : 'Larger than a typical 220×220×250 mm bed, so scale or split the model'}</li>
      <li>${needSup ? '⚠' : '✔'} Overhang area: ${fmt(100 * a.overhangArea / a.area, 1)}% of the surface ${needSup ? '(supports likely needed in this orientation)' : '(little or no support needed)'}</li>
      <li>${a.volume > 0 ? '✔' : '⚠'} ${a.volume > 0 ? 'Volume is positive, so the mesh looks closed (not a full watertight proof)' : 'Zero volume: the mesh may be open'}</li></ul>
      <h3 style="margin-top:12px">Estimate (${S.layer} mm, ${S.infill}% infill)</h3>
      <dl class="kv"><dt>Layers</dt><dd>${e.layers}</dd><dt>Plastic</dt><dd>${fmt(e.total / 1000, 2)} cm³ · ${fmt(e.grams, 1)} g ${S.material}</dd><dt>Print time</dt><dd>≈ ${fmtTime(e.seconds)}</dd><dt>Of which</dt><dd>walls ${fmt(e.shell / 1000, 1)} · infill ${fmt(e.infillV / 1000, 1)} · supports ${fmt(e.supV / 1000, 1)} cm³</dd></dl>`;
  }

  const readFile = async f => {
    try {
      const buf = await f.arrayBuffer(); const p = /\.obj$/i.test(f.name) ? parseOBJ(new TextDecoder().decode(buf)) : parseSTL(buf);
      rot = null; $('#sugg').innerHTML = ''; setModel(p, f.name);
    } catch (e) { $('#stats').innerHTML = `<div class="notice warn">${esc(e.message)}</div>`; }
  };
  $('#file').onchange = e => e.target.files[0] && readFile(e.target.files[0]);
  $('#sample').onclick = () => {
    const g = gearGeometry(18, 12, 10, 5, 3.2).toNonIndexed(); const arr = g.attributes.position.array; rot = null; $('#sugg').innerHTML = ''; setModel(Float32Array.from(arr), 'Sample gear (24 mm)');
  };
  $('#unit').onchange = e => { unit = +e.target.value; refresh(true); };
  $$('[data-r]').forEach(b => b.onclick = () => { if (!base) return; rot = rotate90(pos0(), b.dataset.r, 1); refresh(false); });
  $('#suggest').onclick = () => {
    if (!base) return; const r = suggestOrientations(pos0());
    $('#sugg').innerHTML = `<table><tr><th>Orientation</th><th>Overhang</th><th>Height</th></tr>${r.map((x, i) => `<tr><td>${i === 0 ? '★ ' : ''}${esc(x.name)}</td><td>${fmt(x.overhang / 100, 1)} cm²</td><td>${fmt(x.height, 1)} mm</td></tr>`).join('')}</table><p class="muted" style="font-size:.8rem">Ranked by overhang area (less is better). Taller prints take longer. Use the rotate buttons to apply.</p>`;
  };
  const bind = (id, out, key, conv = parseFloat) => $(id).oninput = e => { S[key] = conv(e.target.value); $(out).textContent = S[key]; if (base) stats(analyze(pos)); };
  bind('#layer', '#lh', 'layer'); bind('#infill', '#inf', 'infill'); bind('#walls', '#wl', 'walls'); bind('#speed', '#sp', 'speed');
  $('#mat').onchange = e => { S.material = e.target.value; if (base) stats(analyze(pos)); };
  $('#sup').onchange = e => { S.supports = e.target.checked; if (base) stats(analyze(pos)); };

  return () => V.dispose();
}
