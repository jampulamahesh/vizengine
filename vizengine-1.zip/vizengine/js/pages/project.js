// Project Studio: a rule-based project scaffold generator (NOT AI). Optional refinement through a connected AI model.
import { $, $$, esc, store, save, download, uid } from '../util.js';
import { BRANCHES } from '../data.js';
import { askAI, aiReady, AGENTS, md } from '../ai.js';

const CATS = ['Mini project', 'Major project', 'Final-year project', 'Research project', 'Prototype project', 'IoT project', 'Robotics project', 'Mechanical project', 'Civil project', 'Electrical project', 'Electronics project', 'AI/ML project'];

// keyword → suggested components [name, role, purpose]
const KB = [
  { re: /solar|photovoltaic|\bpv\b/i, items: [['Solar panel (12 V, 10–20 W)', 'power', 'Harvests energy'], ['Charge controller (PWM/MPPT)', 'power', 'Regulates battery charging'], ['Rechargeable battery (12 V)', 'power', 'Stores energy for night/cloudy use']] },
  { re: /irrigat|soil|plant|farm|agri|garden|crop/i, items: [['Capacitive soil-moisture sensor', 'input', 'Measures soil water content'], ['Water-level sensor', 'input', 'Protects the pump from running dry'], ['Relay module (5 V)', 'output', 'Switches the pump'], ['DC water pump (12 V)', 'output', 'Delivers water'], ['Drip lines / valves', 'mech', 'Distributes water']] },
  { re: /robot|arm|gripper|servo|manipulator|pick/i, items: [['Servo motors (MG996R or similar)', 'output', 'Joint actuation'], ['Motor driver / PCA9685 board', 'process', 'Drives multiple servos'], ['Aluminium / printed links', 'mech', 'Arm structure'], ['Limit switches / encoders', 'input', 'Joint position feedback']] },
  { re: /iot|wifi|wi-fi|cloud|remote|monitor|smart|app/i, items: [['ESP32 module (Wi-Fi/BLE)', 'process', 'Connectivity and control'], ['MQTT broker / cloud dashboard', 'process', 'Remote monitoring and logging']] },
  { re: /bridge|truss|beam|structur|building|concrete|column|foundation/i, items: [['Scale model material (balsa/acrylic/steel)', 'mech', 'Physical structure'], ['Load cells + HX711 amplifier', 'input', 'Measures applied load'], ['Dial gauge / displacement sensor', 'input', 'Measures deflection'], ['Structural analysis software (e.g. open-source FEM)', 'process', 'Compare theory with test']] },
  { re: /motor|\bev\b|electric vehicle|drone|quad|propel|wheel/i, items: [['BLDC / DC motor', 'output', 'Propulsion'], ['ESC / motor controller', 'process', 'Speed and torque control'], ['Li-ion / LiPo battery pack + BMS', 'power', 'Energy storage and protection'], ['Current sensor (INA219)', 'input', 'Power monitoring']] },
  { re: /water|purif|treat|filter|waste|pollut|air quality/i, items: [['pH sensor', 'input', 'Water quality'], ['Turbidity sensor', 'input', 'Clarity measurement'], ['TDS sensor', 'input', 'Dissolved solids'], ['Filter media / membrane', 'mech', 'Treatment stage']] },
  { re: /engine|gear|cam|crank|turbine|heat|thermal|exchanger|boiler|cool|refriger/i, items: [['Thermocouples (K-type) + MAX6675', 'input', 'Temperature measurement'], ['Pressure transducer', 'input', 'Pressure measurement'], ['Test rig frame', 'mech', 'Mounts and supports the system'], ['Data logger', 'process', 'Records experiment data']] },
  { re: /\bai\b|machine learning|vision|camera|detect|classif|recogni|predict|neural/i, items: [['Camera module / dataset', 'input', 'Image or data source'], ['Raspberry Pi / Jetson / laptop', 'process', 'Runs the model'], ['Trained model (TensorFlow Lite / PyTorch)', 'process', 'Inference'], ['Display / alert output', 'output', 'Shows results']] },
  { re: /health|ecg|heart|pulse|patient|medical|biomed|glucose|temperature scan/i, items: [['Biosignal sensor (MAX30102 / AD8232)', 'input', 'Vital-sign acquisition'], ['Microcontroller (ESP32 / Arduino)', 'process', 'Signal processing'], ['OLED display + buzzer', 'output', 'Reading and alarm']] },
  { re: /print|3d|additive|mould|mold/i, items: [['CAD model (STL/STEP)', 'process', 'Part geometry'], ['FDM printer + PLA/PETG filament', 'mech', 'Fabrication'], ['Digital calipers', 'input', 'Dimensional verification']] },
];
const BRANCH_CTRL = {
  default: ['Arduino Uno / ESP32 microcontroller', 'process', 'Reads sensors and controls outputs'],
  cse: ['Server / Raspberry Pi', 'process', 'Hosts the application'], aiml: ['GPU / laptop for training', 'process', 'Model training'],
  civil: ['Data acquisition unit', 'process', 'Collects measurements'], mech: ['Test rig + Arduino DAQ', 'process', 'Collects measurements'],
};

function classify(idea, branch) {
  const items = []; const seen = new Set();
  KB.forEach(k => { if (k.re.test(idea)) k.items.forEach(i => { if (!seen.has(i[0])) { seen.add(i[0]); items.push(i); } }); });
  const hasProc = items.some(i => i[1] === 'process');
  if (!hasProc) items.unshift(BRANCH_CTRL[branch] || BRANCH_CTRL.default);
  return { items, matched: KB.filter(k => k.re.test(idea)).length > 0 };
}
const title = s => s.trim().replace(/^i want to (build|create|make|design|develop)\s+(an?\s+)?/i, '').replace(/[.!?]+$/, '').replace(/\b\w/g, c => c.toUpperCase());

function blockSVG(items) {
  const col = r => items.filter(i => i[1] === r), cols = [col('input'), col('process'), col('output')];
  if (!cols[1].length) cols[1] = [['Controller', 'process']];
  const rows = Math.max(1, ...cols.map(c => c.length)), H = 70 + rows * 64 + (col('power').length ? 70 : 0), W = 720;
  const box = (x, y, t, c) => `<rect x="${x}" y="${y}" width="190" height="46" rx="8" fill="var(--panel2)" stroke="${c}"/><text x="${x + 95}" y="${y + 28}" text-anchor="middle" font-size="11" fill="var(--text)">${esc(t.length > 30 ? t.slice(0, 28) + '…' : t)}</text>`;
  let s = `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Block diagram"><defs><marker id="ar" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8z" fill="var(--mute)"/></marker></defs>`;
  [['INPUTS', 20], ['PROCESSING', 265], ['OUTPUTS', 510]].forEach(([t, x]) => s += `<text x="${x + 95}" y="22" text-anchor="middle" font-size="11" letter-spacing="2" fill="var(--mute)">${t}</text>`);
  const clr = ['var(--accent)', 'var(--accent2)', '#4aa3ff'];
  cols.forEach((c, ci) => c.forEach((it, i) => { const y = 36 + i * 64; s += box([20, 265, 510][ci], y, it[0], clr[ci]); }));
  cols[0].forEach((_, i) => s += `<line x1="210" y1="${59 + i * 64}" x2="265" y2="${59 + (Math.min(i, cols[1].length - 1)) * 64}" stroke="var(--mute)" marker-end="url(#ar)"/>`);
  cols[2].forEach((_, i) => s += `<line x1="455" y1="${59 + (Math.min(i, cols[1].length - 1)) * 64}" x2="510" y2="${59 + i * 64}" stroke="var(--mute)" marker-end="url(#ar)"/>`);
  const pw = col('power'); if (pw.length) { const y = H - 56; s += `<text x="${W / 2}" y="${y - 6}" text-anchor="middle" font-size="11" letter-spacing="2" fill="var(--mute)">POWER</text>`; pw.slice(0, 3).forEach((it, i) => s += box(20 + i * 235, y, it[0], '#ff6b4a')); }
  return s + '</svg>';
}
function flowSVG(idea) {
  const steps = [['Start', 'o'], ['Initialise system', 'r'], ['Read inputs / sensors', 'r'], ['Condition met?', 'd'], ['Perform action', 'r'], ['Log / display status', 'r'], ['Repeat', 'o']];
  let s = `<svg viewBox="0 0 360 ${steps.length * 62 + 10}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Flowchart"><defs><marker id="ar2" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8z" fill="var(--mute)"/></marker></defs>`;
  steps.forEach(([t, k], i) => {
    const y = 10 + i * 62, cx = 150;
    if (k === 'd') s += `<polygon points="${cx},${y} ${cx + 90},${y + 26} ${cx},${y + 52} ${cx - 90},${y + 26}" fill="var(--panel2)" stroke="var(--accent2)"/>`;
    else s += `<rect x="${cx - 80}" y="${y + 4}" width="160" height="44" rx="${k === 'o' ? 22 : 8}" fill="var(--panel2)" stroke="${k === 'o' ? 'var(--accent)' : 'var(--mute)'}"/>`;
    s += `<text x="${cx}" y="${y + 30}" text-anchor="middle" font-size="11" fill="var(--text)">${esc(t)}</text>`;
    if (i < steps.length - 1) s += `<line x1="${cx}" y1="${y + (k === 'd' ? 52 : 48)}" x2="${cx}" y2="${y + 62 + 4}" stroke="var(--mute)" marker-end="url(#ar2)"/>`;
  });
  s += `<text x="258" y="${10 + 3 * 62 + 22}" font-size="11" fill="var(--mute)">no → wait &amp; loop</text><text x="${150 + 6}" y="${10 + 3 * 62 + 66}" font-size="11" fill="var(--mute)">yes</text>`;
  return s + '</svg>';
}

function generate(idea, branchId, cat) {
  const br = BRANCHES.find(b => b.id === branchId), name = title(idea) || 'Untitled project';
  const { items, matched } = classify(idea, branchId);
  const big = /major|final|research/i.test(cat);
  const comp = items.map(i => `| ${i[0]} | ${i[1]} | ${i[2]} |`).join('\n');
  const inputs = items.filter(i => i[1] === 'input'), outs = items.filter(i => i[1] === 'output');
  const S = {
    title: name,
    problem: `[Edit] Describe who is affected and what goes wrong today in the area of “${idea.trim()}”.\nPrompts: Who needs this? What is the current method? What does it cost in time, money, energy or safety? What evidence (a measurement or a reference) shows the problem is real?`,
    objective: `1. Design and build a working prototype of: ${name}.\n2. Define measurable targets (e.g. accuracy ±x %, response time < y s, cost < ₹z).\n3. Test the prototype against those targets and report the results.${big ? '\n4. Compare the experimental result with a theoretical or simulated model.' : ''}`,
    components: `| Component | Role | Purpose |\n|---|---|---|\n${comp}`,
    principle: `[Edit] Explain how the system works in one paragraph.\nStarter structure: ${inputs.length ? `inputs (${inputs.map(i => i[0]).join(', ')})` : 'inputs'} → processing by the controller → ${outs.length ? `outputs (${outs.map(i => i[0]).join(', ')})` : 'outputs'}. State the governing physics/equations of your ${br ? br.name : 'engineering'} domain that apply.`,
    steps: (big
      ? ['Literature survey and requirement list', 'Concept generation and selection', 'Detailed design (calculations, schematics / CAD)', 'Simulation or analytical model', 'Procure components and fabricate subsystems', 'Integrate and calibrate', 'Test, iterate and record data', 'Documentation, report and presentation']
      : ['Define requirements and draw the block diagram', 'Choose and order components', 'Build and test each subsystem separately', 'Integrate subsystems', 'Test the full system and record results', 'Write the report / prepare the demo']).map((x, i) => `${i + 1}. ${x}`).join('\n'),
    simulation: `Suggested simulation concept for ${br ? br.name : 'this domain'}: model the main physical relationship of your system (e.g. a first-order response, load vs deflection, or energy balance) and sweep one parameter. Compare the curve with measured data. You can prototype it in the Simulations lab of VIZENGINE.`,
    testing: ['Component-level checks: verify each part individually against its datasheet.', ...inputs.map(i => `Calibrate and verify: ${i[0]} (compare against a reference instrument).`), ...outs.map(i => `Output test: ${i[0]} responds correctly to commands.`), 'System test: run the full scenario at least 5 times and record pass/fail.', 'Edge cases: power loss, sensor disconnected, out-of-range input.'].map((x, i) => `${i + 1}. ${x}`).join('\n'),
    results: `[Edit after testing] Table of measured vs expected values, with error percentages and a short discussion of the differences.`,
    future: `- Add data logging and a mobile/web dashboard\n- Improve accuracy with better sensors or a control algorithm (PID, filtering)\n- Optimise cost, size and power consumption\n- Scale up to a field or industrial prototype`,
    spec3d: JSON.stringify({ project: name, units: 'mm', parts: items.filter(i => i[1] === 'mech' || /frame|housing|bracket/i.test(i[0])).map(i => ({ name: i[0], dimensions_mm: [null, null, null], material: null })).concat([{ name: 'Enclosure / mounting bracket', dimensions_mm: [null, null, null], material: 'PLA / PETG' }]), note: 'Fill in dimensions. This structured spec can be sent to a CAD or 3D-generation API later.' }, null, 2),
    docs: `1. Title page and abstract\n2. Introduction and problem statement\n3. Literature survey\n4. System design (block diagram, flowchart, schematics)\n5. Implementation\n6. Testing and results\n7. Conclusion and future work\n8. References and appendices (code, datasheets, bill of materials)`,
    slides: `1. Title and team\n2. Problem and motivation\n3. Objectives\n4. System architecture (block diagram)\n5. Components and cost\n6. Working demo / results\n7. Challenges and learnings\n8. Future scope\n9. Q & A`,
  };
  return { S, items, matched };
}

const SECTIONS = [['problem', 'Problem statement'], ['objective', 'Objectives'], ['components', 'Components (Markdown table)'], ['principle', 'Working principle'], ['steps', 'Step-by-step development'], ['simulation', 'Simulation concept'], ['testing', 'Testing plan'], ['results', 'Expected results'], ['future', 'Future improvements'], ['spec3d', '3D model specification (JSON, API-ready)'], ['docs', 'Documentation outline'], ['slides', 'Presentation structure']];
const toMD = S => `# ${S.title}\n\n` + SECTIONS.map(([k, n]) => `## ${n}\n\n${S[k]}\n`).join('\n');

export default function (root) {
  let gen = null;
  root.innerHTML = `
  <div class="page-head"><span class="tag">PROJECT STUDIO</span><h1 style="font-size:2rem;margin-top:8px">From idea to project plan</h1>
  <p>Describe your idea and get a structured project scaffold: components, block diagram, flowchart, build steps, test plan and documentation outline. Edit everything, save it, export it.</p>
  <div class="notice"><b>How this works:</b> the scaffold is built by rules and a keyword knowledge base (not by AI), so it never makes up facts, but it is a starting point. Connect VIZ AI to refine it with a model.</div></div>
  <div class="workspace two"><div>
    <div class="panel"><div class="grid c3"><div><label class="f">Branch</label><select id="br">${BRANCHES.map(b => `<option value="${b.id}">${b.short} · ${esc(b.name)}</option>`).join('')}</select></div>
    <div><label class="f">Category</label><select id="cat">${CATS.map(c => `<option>${c}</option>`).join('')}</select></div><div></div></div>
    <label class="f">Your project idea</label><textarea id="idea" placeholder="e.g. I want to build an automatic solar-powered irrigation system"></textarea>
    <div class="toolbar" style="margin-top:10px"><button class="btn primary" id="gen">Generate project</button><span class="muted">Examples:</span><button class="chip" data-ex="Automatic solar-powered irrigation system">irrigation</button><button class="chip" data-ex="Pick and place robotic arm with camera detection">robot arm</button><button class="chip" data-ex="Smart water quality monitoring system with IoT dashboard">water quality</button></div></div>
    <div id="out"></div></div>
  <div class="panel" id="pside"><h3>Actions</h3><p class="muted">Generate a project first.</p></div></div>`;

  $$('[data-ex]').forEach(b => b.onclick = () => { $('#idea').value = b.dataset.ex; });
  $('#gen').onclick = () => {
    const idea = $('#idea').value.trim(); if (idea.length < 4) { $('#idea').focus(); return; }
    gen = generate(idea, $('#br').value, $('#cat').value); gen.meta = { idea, branch: $('#br').value, cat: $('#cat').value };
    render();
  };
  function render() {
    const { S, items, matched } = gen;
    $('#out').innerHTML = `<h2 style="margin-top:20px">${esc(S.title)}</h2>${matched ? '' : '<div class="notice warn">No domain keywords matched, so only a generic controller was suggested. Mention your sensors, materials or goals (e.g. “solar”, “servo”, “beam”, “IoT”) for a more specific scaffold.</div>'}
      <div class="sect"><h3>Block diagram (generated from components)</h3><div class="diagram">${blockSVG(items)}</div></div>
      <div class="sect"><h3>Flowchart (generic control loop)</h3><div class="diagram">${flowSVG(S.title)}</div></div>
      ${SECTIONS.map(([k, n]) => `<div class="sect section-ed"><h3>${n}</h3><textarea data-k="${k}" rows="${Math.min(14, Math.max(4, S[k].split('\n').length + 1))}">${esc(S[k])}</textarea></div>`).join('')}`;
    $$('#out textarea').forEach(t => t.oninput = () => { S[t.dataset.k] = t.value; });
    $('#pside').innerHTML = `<h3>Actions</h3><div class="list"><button id="save">💾 Save to My Projects</button><button id="md">⬇ Export Markdown</button><button id="print">🖨 Print / save as PDF</button><button id="ai">✧ Refine with VIZ AI</button></div><div id="aiout" style="margin-top:12px"></div>`;
    $('#save').onclick = () => { const p = store('projects', []); p.unshift({ id: uid(), ...gen.meta, title: S.title, sections: S, items, date: new Date().toISOString().slice(0, 10) }); save('projects', p); $('#save').textContent = '✔ Saved'; };
    $('#md').onclick = () => download((S.title || 'project').replace(/\W+/g, '-').toLowerCase() + '.md', toMD(S), 'text/markdown');
    $('#print').onclick = () => print();
    $('#ai').onclick = async () => {
      const o = $('#aiout'); if (!aiReady()) { o.innerHTML = '<div class="notice warn">AI not connected. Open <a href="#/ai-tutor">VIZ AI</a> and click “Connect AI”.</div>'; return; }
      o.textContent = 'Refining…';
      try { o.innerHTML = md(await askAI([{ role: 'system', content: AGENTS.project.system }, { role: 'user', content: `Review and improve this project scaffold. Point out gaps, wrong or missing components, and give concrete numbers where possible.\n\n${toMD(S)}` }])); }
      catch (e) { o.innerHTML = `<div class="notice warn">${esc(e.message)}</div>`; }
    };
  }
  return null;
}
