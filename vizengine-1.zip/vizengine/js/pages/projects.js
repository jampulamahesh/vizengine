import { $, $$, esc, store, save, download } from '../util.js';
import { BRANCHES } from '../data.js';

const SEC = [['problem', 'Problem statement'], ['objective', 'Objectives'], ['components', 'Components'], ['principle', 'Working principle'], ['steps', 'Step-by-step development'], ['simulation', 'Simulation concept'], ['testing', 'Testing plan'], ['results', 'Expected results'], ['future', 'Future improvements'], ['spec3d', '3D model specification'], ['docs', 'Documentation outline'], ['slides', 'Presentation structure']];

export default function (root) {
  let list = store('projects', []);
  function draw() {
    root.innerHTML = `<div class="page-head"><span class="tag">MY PROJECTS</span><h1 style="font-size:2rem;margin-top:8px">My Projects</h1><p>Plans you saved from the Project Studio. Stored in this browser only.</p></div>
    <div class="grid auto">${list.map((p, i) => `<div class="card"><span class="tag">${esc((BRANCHES.find(b => b.id === p.branch) || {}).short || '')}</span> <span class="tag warn">${esc(p.cat || '')}</span><h3 style="margin-top:10px">${esc(p.title)}</h3><p>${esc(p.date || '')}</p>
      <div class="toolbar" style="margin-top:10px"><button class="btn sm" data-md="${i}">⬇ Markdown</button><button class="btn sm danger" data-del="${i}">Delete</button></div></div>`).join('') || `<div class="empty">No saved projects yet. <a href="#/project-studio">Create one in the Project Studio</a>.</div>`}</div>`;
  }
  draw();
  root.onclick = e => {
    const m = e.target.closest('[data-md]'), d = e.target.closest('[data-del]');
    if (m) { const p = list[+m.dataset.md]; download(p.title.replace(/\W+/g, '-').toLowerCase() + '.md', `# ${p.title}\n\n` + SEC.map(([k, n]) => `## ${n}\n\n${p.sections[k] || ''}\n`).join('\n'), 'text/markdown'); }
    if (d && confirm('Delete this project?')) { list.splice(+d.dataset.del, 1); save('projects', list); draw(); }
  };
  return () => { root.onclick = null; };
}
