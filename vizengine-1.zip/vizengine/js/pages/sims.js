// Simulation Lab: real numerical simulations driven by user parameters.
import { $, $$, esc, fmt, sliderRow, bindSliders, fitCanvas, loop, colors, graph, rng } from '../util.js';

const TAU = Math.PI * 2, G2R = Math.PI / 180;
const agm = (a, b) => { for (let i = 0; i < 20; i++) { [a, b] = [(a + b) / 2, Math.sqrt(a * b)]; } return a; };

/* ---------- Pendulum ---------- */
const pendulum = {
  id: 'pendulum', name: 'Simple pendulum', cat: 'Physics · Mechanics', desc: 'Nonlinear pendulum θ″ = −(g/L)·sinθ − b·θ′, integrated numerically (no small-angle approximation).',
  params: [{ id: 'L', label: 'Length', min: .2, max: 3, step: .05, val: 1, unit: ' m' }, { id: 'm', label: 'Mass', min: .1, max: 5, step: .1, val: 1, unit: ' kg' }, { id: 'g', label: 'Gravity', min: 1.6, max: 25, step: .1, val: 9.81, unit: ' m/s²' }, { id: 'a0', label: 'Initial angle', min: 5, max: 170, step: 1, val: 45, unit: '°' }, { id: 'b', label: 'Damping', min: 0, max: 1, step: .01, val: 0, unit: ' 1/s' }],
  reset(s) { s.th = s.a0 * G2R; s.om = 0; s.t = 0; s.tr = []; },
  step(s, dt) {
    const n = 40, h = dt / n;
    for (let i = 0; i < n; i++) { const al = -(s.g / s.L) * Math.sin(s.th) - s.b * s.om; s.om += al * h; s.th += s.om * h; }
    s.t += dt; s.tr.push([s.t, s.th / G2R]); while (s.tr.length && s.tr[0][0] < s.t - 10) s.tr.shift();
  },
  draw(ctx, w, h, s) {
    const px = w * .27, py = 50, sc = Math.min(h - 120, w * .4) / 3, len = s.L * sc;
    const bx = px + Math.sin(s.th) * len, by = py + Math.cos(s.th) * len, r = 10 + 8 * Math.cbrt(s.m);
    ctx.strokeStyle = colors.line; ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px, py + len + 20); ctx.stroke(); ctx.setLineDash([]);
    ctx.strokeStyle = colors.text; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(bx, by); ctx.stroke();
    ctx.fillStyle = colors.accent; ctx.beginPath(); ctx.arc(bx, by, r, 0, TAU); ctx.fill();
    ctx.fillStyle = colors.text; ctx.beginPath(); ctx.arc(px, py, 5, 0, TAU); ctx.fill();
    const tmin = Math.max(0, s.t - 10);
    graph(ctx, w * .52, 30, w * .44, h - 80, [{ pts: s.tr }], { xmin: tmin, xmax: tmin + 10, ymin: -s.a0 - 5, ymax: s.a0 + 5, xlabel: 'time (s)', ylabel: 'θ (deg)' });
  },
  info(s) {
    const T0 = TAU * Math.sqrt(s.L / s.g), T = T0 / agm(1, Math.cos(s.a0 * G2R / 2));
    const E = .5 * s.m * s.L ** 2 * s.om ** 2 + s.m * s.g * s.L * (1 - Math.cos(s.th));
    return `<dl class="kv"><dt>Small-angle T₀</dt><dd>${fmt(T0, 3)} s</dd><dt>Exact period (undamped)</dt><dd>${fmt(T, 3)} s</dd><dt>Angle now</dt><dd>${fmt(s.th / G2R, 1)}°</dd><dt>Energy</dt><dd>${fmt(E, 3)} J</dd></dl><p class="muted">Try changing the mass: the motion does not change, because m cancels out of the equation of motion.</p>`;
  },
};

/* ---------- Projectile ---------- */
const projectile = {
  id: 'projectile', name: 'Projectile motion', cat: 'Physics · Aerospace', desc: 'Trajectory with optional linear air drag, integrated with a small time step.',
  params: [{ id: 'v', label: 'Launch speed', min: 5, max: 100, step: 1, val: 40, unit: ' m/s' }, { id: 'ang', label: 'Launch angle', min: 5, max: 85, step: 1, val: 45, unit: '°' }, { id: 'h0', label: 'Launch height', min: 0, max: 50, step: 1, val: 0, unit: ' m' }, { id: 'c', label: 'Drag coefficient', min: 0, max: .5, step: .01, val: 0, unit: ' 1/s' }],
  reset(s) {
    let x = 0, y = s.h0, vx = s.v * Math.cos(s.ang * G2R), vy = s.v * Math.sin(s.ang * G2R), t = 0, hm = y; const dt = .002, path = [[0, 0, y]];
    while (y >= 0 && t < 200) { vx += -s.c * vx * dt; vy += (-9.81 - s.c * vy) * dt; x += vx * dt; y += vy * dt; t += dt; hm = Math.max(hm, y); if (path.length < 6000 && Math.round(t / dt) % 5 === 0) path.push([t, x, y]); }
    s.path = path; s.T = t; s.range = x; s.hmax = hm; s.t = 0; s.hold = 0;
  },
  step(s, dt) { if (s.t >= s.T) { s.hold += dt; if (s.hold > 1.2) { s.t = 0; s.hold = 0; } } else s.t = Math.min(s.T, s.t + dt); },
  draw(ctx, w, h, s) {
    const m = 40, W = w - 2 * m, H = h - 2 * m, sc = Math.min(W / Math.max(s.range, 1), H / Math.max(s.hmax, 1));
    const X = x => m + x * sc, Y = y => h - m - y * sc;
    ctx.strokeStyle = colors.line; ctx.beginPath(); ctx.moveTo(m, Y(0)); ctx.lineTo(w - m, Y(0)); ctx.stroke();
    ctx.strokeStyle = colors.accent; ctx.lineWidth = 2; ctx.beginPath(); s.path.forEach(([, x, y], i) => i ? ctx.lineTo(X(x), Y(y)) : ctx.moveTo(X(x), Y(y))); ctx.stroke();
    let p = s.path[0]; for (const q of s.path) { if (q[0] <= s.t) p = q; else break; }
    ctx.fillStyle = colors.accent2; ctx.beginPath(); ctx.arc(X(p[1]), Y(p[2]), 7, 0, TAU); ctx.fill();
    ctx.fillStyle = colors.mute; ctx.font = '12px JetBrains Mono, monospace'; ctx.fillText(`t = ${fmt(s.t, 2)} s`, m, 24);
  },
  info(s) {
    const vy = s.v * Math.sin(s.ang * G2R), T0 = (vy + Math.sqrt(vy * vy + 2 * 9.81 * s.h0)) / 9.81;
    return `<dl class="kv"><dt>Range</dt><dd>${fmt(s.range, 1)} m</dd><dt>Max height</dt><dd>${fmt(s.hmax, 1)} m</dd><dt>Flight time</dt><dd>${fmt(s.T, 2)} s</dd>${s.c === 0 ? `<dt>Analytic time</dt><dd>${fmt(T0, 2)} s</dd>` : ''}</dl><p class="muted">${s.c === 0 ? 'With no drag, 45° gives the longest range when launching from ground level.' : 'Drag shortens the range and lowers the best launch angle.'}</p>`;
  },
};

/* ---------- Spring–mass–damper ---------- */
const spring = {
  id: 'spring', name: 'Spring–mass–damper', cat: 'Mechanics · Vibrations', desc: 'm·x″ + c·x′ + k·x = 0. Observe under-, critically and over-damped responses.',
  params: [{ id: 'm', label: 'Mass', min: .1, max: 10, step: .1, val: 1, unit: ' kg' }, { id: 'k', label: 'Spring constant', min: 1, max: 200, step: 1, val: 50, unit: ' N/m' }, { id: 'c', label: 'Damping', min: 0, max: 40, step: .1, val: 2, unit: ' N·s/m' }, { id: 'x0', label: 'Initial displacement', min: -1, max: 1, step: .05, val: .6, unit: ' m' }],
  reset(s) { s.x = s.x0; s.v = 0; s.t = 0; s.tr = []; },
  step(s, dt) { const n = 40, h = dt / n; for (let i = 0; i < n; i++) { const a = (-s.k * s.x - s.c * s.v) / s.m; s.v += a * h; s.x += s.v * h; } s.t += dt; s.tr.push([s.t, s.x]); while (s.tr.length && s.tr[0][0] < s.t - 10) s.tr.shift(); },
  draw(ctx, w, h, s) {
    const y = 80, x0 = 30, sc = 70, bx = w * .25 + s.x * sc;
    ctx.strokeStyle = colors.text; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x0, y - 40); ctx.lineTo(x0, y + 40); ctx.stroke();
    ctx.lineWidth = 2; ctx.strokeStyle = colors.accent; ctx.beginPath(); const n = 12, a = bx - 24 - x0; ctx.moveTo(x0, y);
    for (let i = 1; i <= n; i++) ctx.lineTo(x0 + a * i / n, y + (i % 2 ? -14 : 14) * (i < n ? 1 : 0)); ctx.stroke();
    ctx.fillStyle = colors.accent2; ctx.fillRect(bx - 24, y - 24, 48, 48);
    ctx.setLineDash([4, 4]); ctx.strokeStyle = colors.mute; ctx.beginPath(); ctx.moveTo(w * .25, y - 50); ctx.lineTo(w * .25, y + 50); ctx.stroke(); ctx.setLineDash([]);
    const tmin = Math.max(0, s.t - 10), A = Math.max(.2, Math.abs(s.x0) * 1.1);
    graph(ctx, 30, 150, w - 60, h - 190, [{ pts: s.tr }], { xmin: tmin, xmax: tmin + 10, ymin: -A, ymax: A, xlabel: 'time (s)', ylabel: 'x (m)' });
  },
  info(s) {
    const wn = Math.sqrt(s.k / s.m), z = s.c / (2 * Math.sqrt(s.k * s.m));
    const type = z < 1 - 1e-6 ? 'Under-damped (oscillates)' : z > 1 + 1e-6 ? 'Over-damped (no oscillation)' : 'Critically damped';
    return `<dl class="kv"><dt>ωₙ</dt><dd>${fmt(wn, 3)} rad/s</dd><dt>ζ</dt><dd>${fmt(z, 3)}</dd><dt>Type</dt><dd>${type}</dd>${z < 1 ? `<dt>Damped freq.</dt><dd>${fmt(wn * Math.sqrt(1 - z * z) / TAU, 3)} Hz</dd>` : ''}<dt>Critical c</dt><dd>${fmt(2 * Math.sqrt(s.k * s.m), 2)} N·s/m</dd></dl>`;
  },
};

/* ---------- Series RLC ---------- */
const rlc = {
  id: 'rlc', name: 'Series RLC step response', cat: 'Electrical circuits', desc: 'A DC step applied to a series R–L–C circuit. Plots capacitor voltage and loop current.',
  params: [{ id: 'R', label: 'Resistance', min: 1, max: 200, step: 1, val: 20, unit: ' Ω' }, { id: 'L', label: 'Inductance', min: 1, max: 500, step: 1, val: 100, unit: ' mH' }, { id: 'C', label: 'Capacitance', min: 1, max: 500, step: 1, val: 100, unit: ' µF' }, { id: 'V', label: 'Step voltage', min: 1, max: 24, step: 1, val: 10, unit: ' V' }],
  reset(s) {
    const L = s.L * 1e-3, C = s.C * 1e-6, w0 = 1 / Math.sqrt(L * C), z = s.R / 2 * Math.sqrt(C / L);
    const Tv = z < 1 ? Math.min(8 * TAU / w0, 12 / (z * w0 || 1)) : 10 / (w0 * (z - Math.sqrt(Math.max(0, z * z - 1)) || 1));
    s.Tv = Tv; const n = 4000, h = Tv / n; let q = 0, i = 0; s.vc = []; s.ic = [];
    for (let k = 0; k <= n; k++) { s.vc.push([k * h, q / C]); s.ic.push([k * h, i * 1000]); const a = (s.V - s.R * i - q / C) / L; i += a * h; q += i * h; }
    s.t = 0; s.hold = 0;
  },
  step(s, dt) { s.t += dt * s.Tv / 5; if (s.t > s.Tv * 1.1) s.t = 0; },
  draw(ctx, w, h, s) {
    const iMax = Math.max(1, ...s.ic.map(p => Math.abs(p[1]))), vMax = Math.max(s.V, ...s.vc.map(p => p[1]));
    const t = Math.min(s.t, s.Tv);
    graph(ctx, 50, 26, w - 80, (h - 100) / 2, [{ pts: s.vc }], { xmin: 0, xmax: s.Tv, ymin: 0, ymax: vMax * 1.05, ylabel: 'Vc (V)', cursor: t });
    graph(ctx, 50, 26 + (h - 100) / 2 + 40, w - 80, (h - 100) / 2, [{ pts: s.ic, color: colors.accent2 }], { xmin: 0, xmax: s.Tv, ymin: -iMax, ymax: iMax, xlabel: 'time (s)', ylabel: 'i (mA)', cursor: t });
  },
  info(s) {
    const L = s.L * 1e-3, C = s.C * 1e-6, w0 = 1 / Math.sqrt(L * C), z = s.R / 2 * Math.sqrt(C / L);
    return `<dl class="kv"><dt>f₀</dt><dd>${fmt(w0 / TAU, 2)} Hz</dd><dt>ζ</dt><dd>${fmt(z, 3)}</dd><dt>Response</dt><dd>${z < 1 ? 'Under-damped' : z === 1 ? 'Critical' : 'Over-damped'}</dd><dt>R critical</dt><dd>${fmt(2 * Math.sqrt(L / C), 1)} Ω</dd><dt>Peak Vc</dt><dd>${fmt(Math.max(...s.vc.map(p => p[1])), 2)} V</dd></dl>`;
  },
};

/* ---------- Otto cycle ---------- */
const otto = {
  id: 'otto', name: 'Otto cycle (P–V)', cat: 'Thermodynamics', desc: 'Ideal air-standard Otto cycle. Efficiency depends only on compression ratio and γ.',
  params: [{ id: 'r', label: 'Compression ratio', min: 4, max: 16, step: .5, val: 9, unit: '' }, { id: 'gam', label: 'γ (Cp/Cv)', min: 1.2, max: 1.67, step: .01, val: 1.4 }, { id: 'T1', label: 'Intake temperature', min: 250, max: 400, step: 5, val: 300, unit: ' K' }, { id: 'T3', label: 'Peak temperature', min: 1200, max: 3000, step: 50, val: 2200, unit: ' K' }],
  reset(s) {
    const { r, gam: g, T1, T3 } = s, P1 = 100, V1 = 1, V2 = 1 / r; const T2 = T1 * r ** (g - 1), P2 = P1 * r ** g, P3 = P2 * T3 / T2, T4 = T3 / r ** (g - 1);
    const pts = []; for (let i = 0; i <= 60; i++) { const V = V1 + (V2 - V1) * i / 60; pts.push([V, P1 * (V1 / V) ** g]); }
    pts.push([V2, P3]); for (let i = 0; i <= 60; i++) { const V = V2 + (V1 - V2) * i / 60; pts.push([V, P3 * (V2 / V) ** g]); }
    pts.push([V1, P1]);
    Object.assign(s, { pts, P2, P3, T2, T4, eta: 1 - r ** (1 - g), t: 0, Pmax: P3 });
  },
  step(s, dt) { s.t = (s.t + dt * .12) % 1; },
  draw(ctx, w, h, s) {
    const g = graph(ctx, 60, 30, w - 90, h - 80, [{ pts: s.pts.map(([v, p]) => [v, p]) }], { xmin: 0, xmax: 1.05, ymin: 0, ymax: s.Pmax * 1.05, xlabel: 'volume (relative)', ylabel: 'pressure (kPa)' });
    const p = s.pts[Math.floor(s.t * (s.pts.length - 1))];
    ctx.fillStyle = colors.accent2; ctx.beginPath(); ctx.arc(g.X(p[0]), g.Y(p[1]), 7, 0, TAU); ctx.fill();
    ctx.fillStyle = colors.text; ctx.font = '600 12px Space Grotesk, sans-serif';
    [['1', 1, 100], ['2', 1 / s.r, s.P2], ['3', 1 / s.r, s.P3], ['4', 1, s.P3 / s.r ** s.gam]].forEach(([n, v, pp]) => ctx.fillText(n, g.X(v) + 6, g.Y(pp) - 6));
  },
  info(s) { return `<dl class="kv"><dt>Efficiency η</dt><dd>${fmt(s.eta * 100, 1)} %</dd><dt>T₂ (after compression)</dt><dd>${fmt(s.T2, 0)} K</dd><dt>T₄ (after expansion)</dt><dd>${fmt(s.T4, 0)} K</dd><dt>P₂ / P₃</dt><dd>${fmt(s.P2, 0)} / ${fmt(s.P3, 0)} kPa</dd></dl><p class="muted">η = 1 − r^(1−γ). Raising r raises efficiency, limited in real engines by knock.</p>`; },
};

/* ---------- Venturi / Bernoulli ---------- */
const venturi = {
  id: 'venturi', name: 'Pipe flow (Bernoulli)', cat: 'Fluid mechanics', desc: 'Water flowing through a pipe that changes diameter: continuity (A₁v₁ = A₂v₂) and Bernoulli pressure change.',
  params: [{ id: 'D1', label: 'Inlet diameter', min: 20, max: 100, step: 1, val: 60, unit: ' mm' }, { id: 'D2', label: 'Throat diameter', min: 10, max: 100, step: 1, val: 30, unit: ' mm' }, { id: 'Q', label: 'Flow rate', min: .1, max: 10, step: .1, val: 2, unit: ' L/s' }],
  reset(s) { const R = rng(5); s.p = Array.from({ length: 70 }, () => [R(), R() * 1.8 - .9]); },
  step(s, dt) { const A = d => Math.PI * (d / 2000) ** 2, v1 = s.Q / 1000 / A(s.D1); s.p.forEach(q => { const v = v1 * (s.D1 / this.dia(s, q[0])) ** 2; q[0] += v * dt * .25; if (q[0] > 1) q[0] -= 1; }); },
  dia(s, x) { const u = x < .3 ? 0 : x < .45 ? (x - .3) / .15 : x < .6 ? 1 : x < .75 ? 1 - (x - .6) / .15 : 0; const e = u * u * (3 - 2 * u); return s.D1 + (s.D2 - s.D1) * e; },
  rad(s, x) { return this.dia(s, x) / 2; },
  draw(ctx, w, h, s) {
    const m = 30, W = w - 2 * m, cy = h * .4, k = Math.min(1, (h * .3) / (Math.max(s.D1, s.D2) / 2));
    ctx.fillStyle = colors.panel2; ctx.strokeStyle = colors.text; ctx.lineWidth = 2; ctx.beginPath();
    for (let i = 0; i <= 100; i++) { const x = i / 100; const y = cy - this.rad(s, x) * k; i ? ctx.lineTo(m + x * W, y) : ctx.moveTo(m + x * W, y); }
    for (let i = 100; i >= 0; i--) { const x = i / 100; ctx.lineTo(m + x * W, cy + this.rad(s, x) * k); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = colors.accent;
    s.p.forEach(([x, f]) => { ctx.globalAlpha = .8; ctx.beginPath(); ctx.arc(m + x * W, cy + f * this.rad(s, x) * k, 2.6, 0, TAU); ctx.fill(); }); ctx.globalAlpha = 1;
    const A = d => Math.PI * (d / 2000) ** 2, v1 = s.Q / 1000 / A(s.D1), v2 = s.Q / 1000 / A(s.D2), dp = .5 * 1000 * (v2 * v2 - v1 * v1);
    const by = h - 70, bw = 70; ctx.font = '12px JetBrains Mono, monospace';
    [['Inlet', v1, 0], ['Throat', v2, dp]].forEach(([n, v, d], i) => { const x = m + 10 + i * (W / 2); ctx.fillStyle = colors.accent2; ctx.fillRect(x, by, Math.min(bw * 2, v * 12), 14); ctx.fillStyle = colors.text; ctx.fillText(`${n}: v = ${fmt(v, 2)} m/s`, x, by - 6); });
    ctx.fillStyle = dp > 0 ? colors.danger : colors.accent; ctx.fillText(`Δp (inlet → throat) = ${fmt(-dp / 1000, 2)} kPa`, m + 10, by + 36);
  },
  info(s) { const A = d => Math.PI * (d / 2000) ** 2, v1 = s.Q / 1000 / A(s.D1), v2 = s.Q / 1000 / A(s.D2), dp = .5 * 1000 * (v2 * v2 - v1 * v1), Re = 1000 * v1 * s.D1 / 1000 / 1e-3; return `<dl class="kv"><dt>v₁ (inlet)</dt><dd>${fmt(v1, 2)} m/s</dd><dt>v₂ (throat)</dt><dd>${fmt(v2, 2)} m/s</dd><dt>p₂ − p₁</dt><dd>${fmt(-dp / 1000, 2)} kPa</dd><dt>Re (inlet)</dt><dd>${fmt(Re, 0)} ${Re > 4000 ? '(turbulent)' : Re < 2300 ? '(laminar)' : '(transitional)'}</dd></dl><p class="muted">Faster flow in the narrow throat means lower static pressure (inviscid, incompressible, water at 20 °C).</p>`; },
};

/* ---------- 2-link robot arm IK ---------- */
const arm = {
  id: 'arm', name: '2-link arm kinematics', cat: 'Robotics', desc: 'Inverse kinematics of a planar 2-link arm. Move the target and the joint angles are solved analytically.',
  params: [{ id: 'l1', label: 'Link 1', min: 10, max: 60, step: 1, val: 35, unit: ' cm' }, { id: 'l2', label: 'Link 2', min: 10, max: 60, step: 1, val: 28, unit: ' cm' }, { id: 'tx', label: 'Target x', min: -100, max: 100, step: 1, val: 40, unit: ' cm' }, { id: 'ty', label: 'Target y', min: -100, max: 100, step: 1, val: 30, unit: ' cm' }, { id: 'el', label: 'Elbow (0 down · 1 up)', min: 0, max: 1, step: 1, val: 1 }],
  reset(s) { s.a1 = 0; s.a2 = 0; },
  solve(s) {
    const d2 = s.tx ** 2 + s.ty ** 2, d = Math.sqrt(d2), reach = d <= s.l1 + s.l2 && d >= Math.abs(s.l1 - s.l2);
    let c2 = (d2 - s.l1 ** 2 - s.l2 ** 2) / (2 * s.l1 * s.l2); c2 = Math.max(-1, Math.min(1, c2));
    const t2 = (s.el ? 1 : -1) * Math.acos(c2), t1 = Math.atan2(s.ty, s.tx) - Math.atan2(s.l2 * Math.sin(t2), s.l1 + s.l2 * Math.cos(t2));
    return { t1, t2, reach };
  },
  step(s, dt) { const q = this.solve(s), k = 1 - Math.exp(-8 * dt); s.a1 += (q.t1 - s.a1) * k; s.a2 += (q.t2 - s.a2) * k; },
  draw(ctx, w, h, s) {
    const sc = Math.min(w, h) / 2.3 / Math.max(60, s.l1 + s.l2), ox = w / 2, oy = h / 2, P = (x, y) => [ox + x * sc, oy - y * sc], q = this.solve(s);
    ctx.strokeStyle = colors.line; ctx.setLineDash([4, 5]); [s.l1 + s.l2, Math.abs(s.l1 - s.l2)].forEach(r => { ctx.beginPath(); ctx.arc(ox, oy, r * sc, 0, TAU); ctx.stroke(); }); ctx.setLineDash([]);
    const ex = s.l1 * Math.cos(s.a1), ey = s.l1 * Math.sin(s.a1), tx = ex + s.l2 * Math.cos(s.a1 + s.a2), ty = ey + s.l2 * Math.sin(s.a1 + s.a2);
    ctx.lineCap = 'round'; ctx.lineWidth = 10; ctx.strokeStyle = colors.accent; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(...P(ex, ey)); ctx.stroke();
    ctx.strokeStyle = colors.accent2; ctx.beginPath(); ctx.moveTo(...P(ex, ey)); ctx.lineTo(...P(tx, ty)); ctx.stroke();
    ctx.fillStyle = colors.text; [[0, 0], [ex, ey]].forEach(([x, y]) => { ctx.beginPath(); ctx.arc(...P(x, y), 6, 0, TAU); ctx.fill(); });
    ctx.strokeStyle = q.reach ? colors.ok || '#4ade80' : colors.danger; ctx.lineWidth = 2; const [px, py] = P(s.tx, s.ty); ctx.beginPath(); ctx.moveTo(px - 10, py); ctx.lineTo(px + 10, py); ctx.moveTo(px, py - 10); ctx.lineTo(px, py + 10); ctx.stroke();
  },
  info(s) { const q = this.solve(s); return `<dl class="kv"><dt>θ₁</dt><dd>${fmt(q.t1 / G2R, 1)}°</dd><dt>θ₂</dt><dd>${fmt(q.t2 / G2R, 1)}°</dd><dt>Reach</dt><dd>${fmt(Math.abs(s.l1 - s.l2), 0)}–${fmt(s.l1 + s.l2, 0)} cm</dd><dt>Target</dt><dd>${q.reach ? '<span style="color:var(--ok)">reachable</span>' : '<span style="color:var(--danger)">out of reach (clamped)</span>'}</dd></dl><p class="muted">θ₂ = ±acos((x²+y²−l₁²−l₂²)/(2·l₁·l₂)); the sign selects elbow up or down.</p>`; },
};

const SIMS = [pendulum, projectile, spring, rlc, otto, venturi, arm];

export default function (root, q) {
  let cur = SIMS.find(s => s.id === q.get('s')) || SIMS[0];
  const S = {}; let paused = false;
  root.innerHTML = `
  <div class="page-head"><span class="tag">SIMULATION LAB</span><h1 style="font-size:2rem;margin-top:8px">Change a parameter, watch the physics</h1>
  <p>Each simulation integrates the real governing equations. Results are for learning; they are idealised models, not certified engineering analysis.</p></div>
  <div class="workspace">
    <div class="panel"><h3>Simulations</h3><div class="list" id="slist">${SIMS.map(s => `<button data-id="${s.id}"><span>${esc(s.name)}</span></button>`).join('')}</div></div>
    <div><div class="canvas-box"><canvas id="cv"></canvas></div>
      <div class="toolbar" style="margin-top:10px"><button class="btn sm" id="pause">Pause</button><button class="btn sm" id="restart">Restart</button><span class="tag" id="cat"></span><span class="muted" id="desc"></span></div></div>
    <div class="panel"><h3>Parameters</h3><div id="params"></div><h3 style="margin-top:16px">Results</h3><div id="info"></div></div>
  </div>`;
  const st = fitCanvas($('#cv'));
  function select(sim) {
    cur = sim; Object.keys(S).forEach(k => delete S[k]);
    sim.params.forEach(p => S[p.id] = p.val); sim.reset(S);
    $('#params').innerHTML = sim.params.map(sliderRow).join('');
    bindSliders($('#params'), S, () => sim.reset(S));
    $('#desc').textContent = sim.desc; $('#cat').textContent = sim.cat;
    $$('#slist button').forEach(b => b.classList.toggle('active', b.dataset.id === sim.id));
    history.replaceState(null, '', '#/simulations?s=' + sim.id);
  }
  $('#slist').onclick = e => { const b = e.target.closest('button'); if (b) select(SIMS.find(s => s.id === b.dataset.id)); };
  $('#pause').onclick = e => { paused = !paused; e.target.textContent = paused ? 'Play' : 'Pause'; };
  $('#restart').onclick = () => cur.reset(S);
  select(cur);
  let n = 0;
  const stop = loop(dt => {
    const { ctx, w, h } = st; ctx.clearRect(0, 0, w, h);
    if (!paused) cur.step(S, dt);
    cur.draw(ctx, w, h, S);
    if (n++ % 6 === 0) $('#info').innerHTML = cur.info(S);
  });
  return () => { stop(); st.destroy(); };
}
