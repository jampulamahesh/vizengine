import { $, $$, esc, store, save, uid } from '../util.js';
import { AGENTS, askAI, aiReady, md, openAISettings, aiConfig } from '../ai.js';

const SUGGEST = ['Explain thermodynamics', 'Create a visual explanation of a four-stroke engine', 'Help me design a mechanical engineering project', 'Explain how a transistor works as a switch', 'Create a project plan for a solar-powered irrigation system'];

export default function (root) {
  let chats = store('chats', []), cur = chats[0] || null, busy = false, ctrl = null;
  const persist = () => save('chats', chats.slice(0, 30));

  root.innerHTML = `
  <div class="page-head"><span class="tag">VIZ AI</span><h1 style="font-size:2rem;margin-top:8px">Your engineering AI tutor</h1>
  <p>Tutor, doubt solver, project mentor and more. Answers come from the AI model you connect. VIZENGINE never invents AI responses.</p></div>
  <div class="workspace">
    <div class="panel"><div class="toolbar"><button class="btn sm primary" id="new">+ New chat</button></div><h3 style="margin-top:14px">History (this browser)</h3><div class="list" id="hist"></div></div>
    <div class="panel chat">
      <div class="toolbar" style="margin-bottom:8px"><label class="muted" for="agent">Mode</label>
        <select id="agent" style="width:auto">${Object.entries(AGENTS).map(([k, a]) => `<option value="${k}">${a.name}</option>`).join('')}</select>
        <span class="tag" id="status"></span><button class="btn sm ghost" id="cfg" style="margin-left:auto">⚙ Connect AI</button></div>
      <div class="msgs" id="msgs" aria-live="polite"></div>
      <div class="composer"><textarea id="inp" placeholder="Ask an engineering question…" rows="1"></textarea><button class="btn primary" id="send">Send</button></div>
    </div>
    <div class="panel"><h3>Try asking</h3><div class="list" id="sug">${SUGGEST.map(s => `<button>${esc(s)}</button>`).join('')}</div>
      <div class="notice" style="margin-top:14px">Image questions and numerical practice are in <a href="#/exam">Exam Preparation</a>.</div></div>
  </div>`;

  function status() { const ok = aiReady(); const t = $('#status'); t.textContent = ok ? 'connected · ' + aiConfig().model : 'AI not connected'; t.className = 'tag' + (ok ? '' : ' warn'); }
  function renderHist() {
    $('#hist').innerHTML = chats.length ? chats.map(c => `<button data-id="${c.id}" class="${cur && c.id === cur.id ? 'active' : ''}"><span>${esc(c.title)}</span></button>`).join('') : '<span class="muted" style="padding:6px">No conversations yet.</span>';
  }
  function renderMsgs() {
    const m = $('#msgs');
    if (!cur || !cur.messages.length) {
      m.innerHTML = `<div class="msg"><p>Hi! I'm <b>VIZ AI</b>. Ask me anything in engineering.</p>${aiReady() ? '' : '<p class="muted">The AI is <b>not connected yet</b>. Click “Connect AI” and add an OpenAI-compatible endpoint and key to get answers.</p>'}</div>`;
    } else m.innerHTML = cur.messages.map(x => `<div class="msg ${x.role === 'user' ? 'user' : ''} ${x.err ? 'err' : ''}">${x.role === 'user' ? `<p>${esc(x.content).replace(/\n/g, '<br>')}</p>` : md(x.content)}</div>`).join('');
    m.scrollTop = m.scrollHeight;
  }
  function newChat() { cur = { id: uid(), title: 'New chat', messages: [] }; chats.unshift(cur); persist(); renderHist(); renderMsgs(); }

  async function send(text) {
    text = text.trim(); if (!text || busy) return;
    if (!cur) newChat();
    if (cur.messages.length === 0) cur.title = text.slice(0, 40);
    cur.messages.push({ role: 'user', content: text }); $('#inp').value = ''; persist(); renderHist(); renderMsgs();
    if (!aiReady()) { cur.messages.push({ role: 'assistant', content: 'The AI is **not connected**, so I cannot answer yet. Click **Connect AI** (top right of this panel) and add an endpoint and API key.', err: true }); persist(); renderMsgs(); return; }
    busy = true; $('#send').disabled = true;
    const typing = document.createElement('div'); typing.className = 'msg'; typing.textContent = 'Thinking…'; $('#msgs').appendChild(typing); $('#msgs').scrollTop = 1e9;
    try {
      ctrl = new AbortController();
      const msgs = [{ role: 'system', content: AGENTS[$('#agent').value].system }, ...cur.messages.filter(x => !x.err).slice(-16).map(({ role, content }) => ({ role, content }))];
      const out = await askAI(msgs, { signal: ctrl.signal });
      cur.messages.push({ role: 'assistant', content: out });
    } catch (e) { cur.messages.push({ role: 'assistant', content: e.name === 'AbortError' ? 'Cancelled.' : String(e.message || e), err: true }); }
    busy = false; $('#send').disabled = false; persist(); renderMsgs();
  }

  $('#send').onclick = () => send($('#inp').value);
  $('#inp').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send($('#inp').value); } });
  $('#new').onclick = newChat;
  $('#cfg').onclick = () => openAISettings(() => { status(); renderMsgs(); });
  $('#hist').onclick = e => { const b = e.target.closest('button'); if (b) { cur = chats.find(c => c.id === b.dataset.id); renderHist(); renderMsgs(); } };
  $('#sug').onclick = e => { const b = e.target.closest('button'); if (b) send(b.textContent); };
  status(); renderHist(); renderMsgs();
  return () => ctrl && ctrl.abort();
}
