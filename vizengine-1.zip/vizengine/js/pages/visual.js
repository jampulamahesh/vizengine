import { $, $$, esc, sliderRow, bindSliders, fitCanvas, loop, colors } from '../util.js';
import { CONCEPTS } from '../concepts.js';

export default function (root, q) {
  let cur = CONCEPTS.find(c => c.id === q.get('c')) || CONCEPTS[0];
  const S = {}; let paused = false;
  root.innerHTML = `
  <div class="page-head"><span class="tag">VISUAL LEARNING LAB</span><h1 style="font-size:2rem;margin-top:8px">See how it works</h1>
  <p>Pick a concept, change the parameters and watch the mechanism respond. All figures on screen are computed live from the parameters.</p></div>
  <div class="workspace">
    <div class="panel"><h3>Concepts</h3><div class="list" id="clist">${CONCEPTS.map(c => `<button data-id="${c.id}"><span>${esc(c.name)}</span><small>${esc(c.branch.split(' ')[0])}</small></button>`).join('')}</div></div>
    <div><div class="canvas-box"><canvas id="cv"></canvas></div>
      <div class="toolbar" style="margin-top:10px"><button class="btn sm" id="pause">Pause</button><button class="btn sm" id="reset">Restart</button><span class="muted" id="desc"></span></div></div>
    <div class="panel"><h3>Parameters</h3><div id="params"></div><h3 style="margin-top:16px">Readout</h3><div id="info"></div><div id="rel"></div></div>
  </div>`;
  const st = fitCanvas($('#cv'));
  function select(c) {
    cur = c;
    Object.keys(S).forEach(k => delete S[k]);
    c.params.forEach(p => S[p.id] = p.val);
    c.init && c.init(S);
    $('#params').innerHTML = c.params.map(sliderRow).join('');
    bindSliders($('#params'), S, () => { if (c.id === 'rc') S.tt = 0; });
    $('#desc').textContent = c.desc;
    $$('#clist button').forEach(b => b.classList.toggle('active', b.dataset.id === c.id));
    $('#rel').innerHTML = c.lab3d ? `<p style="margin-top:12px"><a href="${c.lab3d}">Open the 3D / 4D version →</a></p>` : '';
    history.replaceState(null, '', '#/visual-lab?c=' + c.id);
  }
  $('#clist').onclick = e => { const b = e.target.closest('button'); if (b) select(CONCEPTS.find(c => c.id === b.dataset.id)); };
  $('#pause').onclick = e => { paused = !paused; e.target.textContent = paused ? 'Play' : 'Pause'; };
  $('#reset').onclick = () => { S.angle = 0; S.phi = 0; S.tt = 0; };
  select(cur);
  let tick = 0;
  const stop = loop((dt, t) => {
    const { ctx, w, h } = st;
    ctx.clearRect(0, 0, w, h);
    cur.draw(ctx, w, h, S, t, paused ? 0 : dt);
    if (tick++ % 6 === 0) $('#info').innerHTML = cur.info(S);
  });
  return () => { stop(); st.destroy(); };
}
