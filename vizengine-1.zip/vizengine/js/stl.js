// STL / OBJ parsing and printability analysis. Pure JavaScript (no Three.js) so it can be unit-tested.
// All geometry is a flat Float32Array of triangle vertices [x,y,z, x,y,z, x,y,z, ...]. Units: model units (usually mm).

export function parseSTL(buf) {
  const dv = new DataView(buf);
  if (buf.byteLength > 84) {
    const n = dv.getUint32(80, true);
    if (84 + n * 50 === buf.byteLength) {           // binary STL
      const out = new Float32Array(n * 9);
      for (let i = 0; i < n; i++) {
        const o = 84 + i * 50 + 12;
        for (let k = 0; k < 9; k++) out[i * 9 + k] = dv.getFloat32(o + k * 4, true);
      }
      return out;
    }
  }
  const text = new TextDecoder().decode(buf);       // ASCII STL
  const re = /vertex\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)/g, v = [];
  let m; while ((m = re.exec(text))) v.push(+m[1], +m[2], +m[3]);
  if (v.length === 0 || v.length % 9) throw new Error('Could not read this STL file (no valid triangles found).');
  return new Float32Array(v);
}

export function parseOBJ(text) {
  const verts = [], out = [];
  for (const line of text.split(/\r?\n/)) {
    const p = line.trim().split(/\s+/);
    if (p[0] === 'v') verts.push([+p[1], +p[2], +p[3]]);
    else if (p[0] === 'f') {
      const idx = p.slice(1).map(s => { const i = parseInt(s.split('/')[0], 10); return i < 0 ? verts.length + i : i - 1; });
      for (let i = 1; i < idx.length - 1; i++) for (const k of [idx[0], idx[i], idx[i + 1]]) { const v = verts[k]; if (!v) throw new Error('OBJ face refers to a missing vertex.'); out.push(...v); }
    }
  }
  if (!out.length) throw new Error('Could not read this OBJ file (no faces found).');
  return new Float32Array(out);
}

// rotate by multiples of 90° about an axis ('x'|'y'|'z'); returns a new array
export function rotate90(pos, axis, times = 1) {
  const out = new Float32Array(pos.length);
  for (let i = 0; i < pos.length; i += 3) {
    let x = pos[i], y = pos[i + 1], z = pos[i + 2];
    for (let t = 0; t < times; t++) {
      if (axis === 'x') [y, z] = [-z, y];
      else if (axis === 'y') [x, z] = [z, -x];
      else [x, y] = [-y, x];
    }
    out[i] = x; out[i + 1] = y; out[i + 2] = z;
  }
  return out;
}
export function scaled(pos, k) { const o = new Float32Array(pos.length); for (let i = 0; i < o.length; i++) o[i] = pos[i] * k; return o; }

// Z is up (print direction). Faces whose normal points more than 45° below horizontal need support, unless they sit on the bed.
export function analyze(pos, overhangDeg = 45) {
  let vol = 0, area = 0, over = 0;
  const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < pos.length; i += 3) for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], pos[i + k]); mx[k] = Math.max(mx[k], pos[i + k]); }
  const thr = -Math.cos((90 - overhangDeg) * Math.PI / 180), bed = mn[2] + 0.2;
  let overProj = 0, overH = 0;
  for (let i = 0; i < pos.length; i += 9) {
    const [ax, ay, az, bx, by, bz, cx, cy, cz] = [pos[i], pos[i + 1], pos[i + 2], pos[i + 3], pos[i + 4], pos[i + 5], pos[i + 6], pos[i + 7], pos[i + 8]];
    const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, len = Math.hypot(nx, ny, nz);
    const a = len / 2; area += a;
    vol += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6;
    if (len > 0 && nz / len < thr && Math.max(az, bz, cz) > bed) {
      over += a; const proj = Math.abs(nz) / 2; overProj += proj; overH += proj * ((az + bz + cz) / 3 - mn[2]);
    }
  }
  const size = [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]];
  return { triangles: pos.length / 9, min: mn, max: mx, size, volume: Math.abs(vol), area, overhangArea: over, overhangProj: overProj, supportVolumeRaw: overH, closedHint: Math.abs(vol) > 1e-9 };
}

export const MATERIALS = { PLA: 1.24, PETG: 1.27, ABS: 1.04, TPU: 1.21 };

// Rough FDM estimate: shell (walls) + sparse infill + optional support
export function estimate(a, { layer = 0.2, infill = 20, walls = 2, speed = 50, supports = false, material = 'PLA', nozzle = 0.4 }) {
  const shell = Math.min(a.volume, a.area * walls * nozzle * 0.85);
  const infillV = Math.max(0, a.volume - shell) * infill / 100;
  const supV = supports ? a.supportVolumeRaw * 0.15 : 0;
  const total = shell + infillV + supV;                       // mm³ of plastic
  const flow = layer * nozzle * speed;                          // mm³/s volumetric rate
  const seconds = total / flow * 1.3 + (a.size[2] / layer) * 2; // +30% travel/accel, +2 s per layer
  return { shell, infillV, supV, total, grams: total / 1000 * MATERIALS[material], seconds, layers: Math.ceil(a.size[2] / layer) };
}
export function fmtTime(s) { const h = Math.floor(s / 3600), m = Math.round((s % 3600) / 60); return h ? `${h} h ${m} min` : `${m} min`; }

// try the 6 principal orientations and rank them by overhang area
export function suggestOrientations(pos) {
  const tries = [['As loaded', pos], ['Rotate 90° about X', rotate90(pos, 'x', 1)], ['Rotate 180° about X', rotate90(pos, 'x', 2)], ['Rotate 270° about X', rotate90(pos, 'x', 3)], ['Rotate 90° about Y', rotate90(pos, 'y', 1)], ['Rotate 270° about Y', rotate90(pos, 'y', 3)]];
  return tries.map(([name, p], i) => { const a = analyze(p); return { name, i, overhang: a.overhangArea, height: a.size[2] }; }).sort((x, y) => x.overhang - y.overhang);
}
