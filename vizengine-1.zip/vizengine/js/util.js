// Shared helpers for VIZENGINE (no external dependencies)
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function store(k, d) {
  try { const v = localStorage.getItem('viz:' + k); return v == null ? d : JSON.parse(v); } catch { return d; }
}
export function save(k, v) {
  try { localStorage.setItem('viz:' + k, JSON.stringify(v)); return true; } catch { return false; }
}
export function download(name, data, type = 'text/plain') {
  const b = data instanceof Blob ? data : new Blob([data], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
export const fmt = (n, d = 3) => String(+(+n).toFixed(d));
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const uid = () => Math.random().toString(36).slice(2, 9);

// theme colours for canvas drawing (kept in sync with CSS variables)
export let colors = {};
export function refreshColors() {
  const s = getComputedStyle(document.documentElement);
  const g = n => s.getPropertyValue(n).trim();
  colors = { bg: g('--bg'), bg2: g('--bg2'), panel: g('--panel'), panel2: g('--panel2'), line: g('--line'), text: g('--text'), mute: g('--mute'), accent: g('--accent'), accent2: g('--accent2'), danger: g('--danger') };
}
refreshColors();

// canvas that tracks its CSS size and device pixel ratio
export function fitCanvas(c) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const ctx = c.getContext('2d');
  const st = { ctx, w: 0, h: 0, canvas: c };
  const fit = () => {
    const r = c.getBoundingClientRect();
    st.w = Math.max(10, r.width); st.h = Math.max(10, r.height);
    c.width = Math.round(st.w * dpr); c.height = Math.round(st.h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  fit();
  const ro = new ResizeObserver(fit); ro.observe(c);
  st.destroy = () => ro.disconnect();
  return st;
}

export function loop(fn) {
  let id, last = performance.now(), run = true;
  const f = now => {
    if (!run) return;
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    try { fn(dt, now / 1000); } catch (e) { console.error(e); }
    id = requestAnimationFrame(f);
  };
  id = requestAnimationFrame(f);
  return () => { run = false; cancelAnimationFrame(id); };
}

// gear outline: R = outer radius, depth = tooth height
export function drawGear(ctx, x, y, R, n, rot, fill, stroke, depth, hole = 0.18) {
  const root = R - depth, p = Math.PI * 2 / n;
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const a = rot + i * p;
    const pts = [[root, 0], [R, 0.15], [R, 0.45], [root, 0.6]];
    pts.forEach(([r, f], j) => {
      const px = x + Math.cos(a + f * p) * r, py = y + Math.sin(a + f * p) * r;
      (i === 0 && j === 0) ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    });
  }
  ctx.closePath();
  ctx.moveTo(x + root * hole * 2 + root * 0.0, y);
  ctx.arc(x, y, Math.max(2, root * (hole + .1)), 0, Math.PI * 2, true);
  if (fill) { ctx.fillStyle = fill; ctx.fill('evenodd'); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; ctx.stroke(); }
}

export function sliderRow(p) {
  return `<label class="row"><span>${esc(p.label)}</span><output>${fmt(p.val)}${esc(p.unit || '')}</output>` +
    `<input type="range" data-p="${p.id}" data-unit="${esc(p.unit || '')}" min="${p.min}" max="${p.max}" step="${p.step}" value="${p.val}"></label>`;
}
export function bindSliders(root, state, onChange) {
  $$('input[type=range][data-p]', root).forEach(inp => {
    const out = inp.parentElement.querySelector('output');
    inp.addEventListener('input', () => {
      state[inp.dataset.p] = parseFloat(inp.value);
      out.textContent = fmt(inp.value) + (inp.dataset.unit || '');
      onChange && onChange(inp.dataset.p);
    });
  });
}

export function rng(seed) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

// simple line graph used by labs and simulations
export function graph(ctx, x, y, w, h, series, o = {}) {
  const { xmin = 0, xmax = 1, ymin = 0, ymax = 1, xlabel = '', ylabel = '', cursor } = o;
  ctx.save();
  ctx.fillStyle = colors.panel; ctx.strokeStyle = colors.line; ctx.lineWidth = 1;
  ctx.fillRect(x, y, w, h); ctx.strokeRect(x + .5, y + .5, w, h);
  ctx.font = '11px ' + 'JetBrains Mono, monospace'; ctx.fillStyle = colors.mute;
  const X = v => x + (v - xmin) / (xmax - xmin || 1) * w, Y = v => y + h - (v - ymin) / (ymax - ymin || 1) * h;
  for (let i = 0; i <= 4; i++) {
    const gy = y + h * i / 4, gx = x + w * i / 4;
    ctx.strokeStyle = colors.line; ctx.globalAlpha = .5;
    ctx.beginPath(); ctx.moveTo(x, gy); ctx.lineTo(x + w, gy); ctx.moveTo(gx, y); ctx.lineTo(gx, y + h); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillText(fmt(ymax - (ymax - ymin) * i / 4, 2), x + 4, gy + (i === 4 ? -4 : 12));
    ctx.fillText(fmt(xmin + (xmax - xmin) * i / 4, 2), gx + (i === 4 ? -34 : 3), y + h - 4);
  }
  if (xlabel) ctx.fillText(xlabel, x + w / 2 - 20, y + h + 14);
  if (ylabel) ctx.fillText(ylabel, x + 4, y - 4);
  series.forEach(s => {
    ctx.strokeStyle = s.color || colors.accent; ctx.lineWidth = 2; ctx.beginPath();
    s.pts.forEach(([a, b], i) => { const px = X(a), py = Y(b); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
    ctx.stroke();
  });
  if (cursor != null) {
    ctx.strokeStyle = colors.accent2; ctx.setLineDash([4, 4]); ctx.beginPath();
    ctx.moveTo(X(cursor), y); ctx.lineTo(X(cursor), y + h); ctx.stroke(); ctx.setLineDash([]);
  }
  ctx.restore();
  return { X, Y };
}

export function trackVisit(key) {
  const v = store('visits', {}); v[key] = (v[key] || 0) + 1; save('visits', v);
  const r = store('recent', []).filter(k => k !== key); r.unshift(key); save('recent', r.slice(0, 8));
}
