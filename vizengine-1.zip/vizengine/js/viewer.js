// Thin Three.js viewer wrapper shared by the 3D Lab, 4D Lab and 3D Printing Lab.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { loop } from './util.js';

export { THREE };

export function createViewer(host) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.localClippingEnabled = true;
  host.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 500);
  camera.position.set(4.5, 3.2, 6);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.target.set(0, 1.2, 0);

  scene.add(new THREE.HemisphereLight(0xdfeaff, 0x1a2233, 1.0));
  const sun = new THREE.DirectionalLight(0xffffff, 2.2); sun.position.set(5, 8, 6); scene.add(sun);
  const fill = new THREE.DirectionalLight(0x6fe9d4, 0.6); fill.position.set(-6, 2, -4); scene.add(fill);

  const grid = new THREE.GridHelper(12, 24, 0x35e0c2, 0x24344d);
  grid.material.transparent = true; grid.material.opacity = 0.35; grid.position.y = -0.01;
  scene.add(grid);

  const cbs = [];
  function resize() {
    const r = host.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;
    renderer.setSize(r.width, r.height, false);
    camera.aspect = r.width / r.height; camera.updateProjectionMatrix();
  }
  resize();
  const ro = new ResizeObserver(resize); ro.observe(host);
  const stop = loop((dt, t) => { cbs.forEach(f => f(dt, t)); controls.update(); renderer.render(scene, camera); });

  const v = new THREE.Vector3();
  return {
    THREE, renderer, scene, camera, controls, grid, host,
    onFrame: f => cbs.push(f),
    project(p) { v.copy(p).project(camera); const r = host.getBoundingClientRect(); return { x: (v.x * .5 + .5) * r.width, y: (-v.y * .5 + .5) * r.height, ok: v.z < 1 }; },
    resetView(target = [0, 1.2, 0], pos = [4.5, 3.2, 6]) { controls.target.set(...target); camera.position.set(...pos); controls.update(); },
    dispose() {
      stop(); ro.disconnect(); controls.dispose();
      scene.traverse(o => { o.geometry && o.geometry.dispose(); if (o.material) [].concat(o.material).forEach(m => m.dispose()); });
      renderer.dispose(); renderer.domElement.remove();
    },
  };
}
